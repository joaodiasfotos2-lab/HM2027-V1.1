  // =================================================================
  // Seleções Nacionais (Mundial / Taça do Mundo e Europeu) — 2026-09-26
  // =================================================================
  // Não jogável: o utilizador só vê resultados/notícias. As seleções seguem a estrutura real
  // atual da World Skate Europe (Europeu) e da Taça do Mundo da World Skate (escalão principal
  // do Mundial, sem Intercontinental/Challenger) — ver plano aprovado em Plan Mode
  // (2026-09-26) para a investigação completa e as fontes. As duas provas têm EXATAMENTE o
  // mesmo formato (8 seleções, 2 grupos de 4 por classificação, todas as 8 avançam a
  // quartos-de-final) — só a lista de participantes muda — por isso só há UM gerador de torneio
  // (Fase 2), não dois.
  //
  // Fase 1: modelo de dados + convocatória. Fase 2 (mais abaixo): resolução do torneio (grupos,
  // eliminatórias, notícias por jornada), incluindo a vantagem de casa do país organizador
  // sorteado e a proteção das estatísticas de clube dos jogadores reais.

  // As 12 nações cobertas pelas duas provas (Portugal/Espanha/Itália/França jogam as duas).
  // `flagCode` é o mesmo código já usado por nationalityFlagCode/img/flags (nenhuma bandeira
  // nova é precisa). `color` é a cor nacional real (bandeira/equipamento), usada como logo/
  // destaque visual da seleção em vez do brasão de um clube — pedido do utilizador ("põe as
  // cores verdadeiras e a bandeira como logo"): a seleção não tem brasão de clube, por isso a
  // própria bandeira faz de logo em toda a UI/notícias (ver Fase 2/3).
  const SELECAO_NATIONS = {
    pt: { code:"pt", nome:"Portugal",    flagCode:"pt",     color:"#D4213D" },
    es: { code:"es", nome:"Espanha",     flagCode:"es",     color:"#C60B1E" },
    it: { code:"it", nome:"Itália",      flagCode:"it",     color:"#00529B" },
    en: { code:"en", nome:"Inglaterra",  flagCode:"gb-eng", color:"#CF081F" },
    fr: { code:"fr", nome:"França",      flagCode:"fr",     color:"#0055A4" },
    de: { code:"de", nome:"Alemanha",    flagCode:"de",     color:"#1A1A1A" },
    ch: { code:"ch", nome:"Suíça",       flagCode:"ch",     color:"#FF0000" },
    at: { code:"at", nome:"Áustria",     flagCode:"at",     color:"#ED2939" },
    ar: { code:"ar", nome:"Argentina",   flagCode:"ar",     color:"#75AADB" },
    cl: { code:"cl", nome:"Chile",       flagCode:"cl",     color:"#D52B1E" },
    ao: { code:"ao", nome:"Angola",      flagCode:"ao",     color:"#CE1126" },
    co: { code:"co", nome:"Colômbia",    flagCode:"co",     color:"#FCD116" },
  };
  // Ordem = classificação inicial (semente da 1ª edição de cada prova, por historial real —
  // ver "Factos reais confirmados" no plano); edições seguintes usam state.selecoesRanking.
  const SELECAO_EUROPEU_ORDER = ["es","pt","it","fr","en","de","ch","at"];
  const SELECAO_MUNDIAL_ORDER = ["es","pt","it","ar","fr","cl","ao","co"];
  // =================================================================
  // Sub-19 (2026-10-14): as mesmas duas provas, no escalão Sub-19, disputadas SEMPRE imediatamente
  // antes da prova sénior correspondente (acaba uma, começa a outra). Reaproveitam este motor
  // inteiro: a única diferença estrutural é o prefixo "s19-" nos códigos de nação (ex. "s19-pt"),
  // o que separa por si só as equipas virtuais (selecaoNacional-s19-pt), a última convocatória
  // (state.selecoesUltimaConvocatoria["s19-pt"]), os links clicáveis (data-selecao="s19-pt") e o
  // histórico/ranking (chave prova = "mundial-s19"/"europeu-s19") das seniores. A edição em curso
  // vive em state.selecoes.edicaoS19 (a sénior continua em state.selecoes.edicao).
  // =================================================================
  const SELECAO_S19_PREFIX = "s19-";
  function selecaoIsS19Code(code){ return typeof code==="string" && code.indexOf(SELECAO_S19_PREFIX)===0; }
  function selecaoBaseCode(code){ return selecaoIsS19Code(code) ? code.slice(SELECAO_S19_PREFIX.length) : code; }
  function selecaoNationOf(code){ return SELECAO_NATIONS[selecaoBaseCode(code)]; }
  function selecaoProvaIsS19(prova){ return typeof prova==="string" && prova.slice(-4)==="-s19"; }
  function selecaoProvaBase(prova){ return selecaoProvaIsS19(prova) ? prova.slice(0,-4) : prova; }
  function selecaoNationCodesFor(prova){
    const base = selecaoProvaBase(prova)==="mundial" ? SELECAO_MUNDIAL_ORDER : SELECAO_EUROPEU_ORDER;
    return selecaoProvaIsS19(prova) ? base.map(c=>SELECAO_S19_PREFIX+c) : base;
  }
  // Edição em curso (sénior ou sub-19) a que pertence uma competição — resolveSelecaoMatch precisa
  // dela para acumular as estatísticas da prova sem depender de qual das duas está a decorrer.
  function selecaoEdicaoDeCompeticao(competitionId){
    const sel = state.selecoes || {};
    if(sel.edicao && sel.edicao.competitionId===competitionId) return sel.edicao;
    if(sel.edicaoS19 && sel.edicaoS19.competitionId===competitionId) return sel.edicaoS19;
    return null;
  }
  function selecaoLogoHtml(code, cls){
    const nation = selecaoNationOf(code);
    if(!nation) return "";
    return `<img class="${cls||"nat-flag"}" src="img/flags/${nation.flagCode}.svg" alt="" title="${escapeHtml(nation.nome)}${selecaoIsS19Code(code)?" Sub-19":""}">`;
  }
  // Bandeira+nome de uma seleção, clicável em qualquer sítio onde apareça (classificação,
  // histórico, notícias de sorteio/campeão/convocatória) — pedido do utilizador (2026-09-27):
  // "as seleções têm de ser clicáveis". Abre o modal com a última convocatória (openSelecaoModal,
  // 05-ui-navegacao.js), através do mesmo mecanismo de delegação global de outros botões
  // (data-selecao) — nameFirst inverte a ordem bandeira/nome (usado nas linhas de jornada, cujo
  // lado "away" mostra nome antes da bandeira, para as duas colunas ficarem simétricas em torno
  // do marcador). extraCls acrescenta classes de alinhamento (ex. jr-home/jr-away).
  function selecaoNationLinkHtml(code, extraCls, nameFirst){
    const nation = selecaoNationOf(code);
    if(!nation) return escapeHtml(code||"?");
    const flag = selecaoLogoHtml(code), name = escapeHtml(nation.nome);
    const inner = nameFirst ? (name+flag) : (flag+name);
    return `<button type="button" class="selecao-link${extraCls?(" "+extraCls):""}" data-selecao="${code}">${inner}</button>`;
  }
  // Procura o clube REAL (nunca uma equipa virtual "selecaoNacional-*") a que um jogador
  // pertence atualmente — usado para tornar o nome de um convocado clicável no modal da
  // seleção (playerLinkHtml precisa do teamId). Devolve null para um jogador fictício
  // (__selecaoFiller, nunca existe em nenhum team.players) ou se, entretanto, já não jogar em
  // lado nenhum (não deve acontecer, mas fica defensivo).
  function teamIdForRealPlayer(playerId){
    for(const t of Object.values(state.teams)){
      if(t.id && t.id.indexOf("selecaoNacional-")===0) continue;
      if(t.players && t.players.some(p=>p.id===playerId)) return t.id;
    }
    // Sub-19: os jovens podem vir da academia (team.academy.brackets.*, 08b-academia-juvenis.js).
    for(const t of Object.values(state.teams)){
      if(t.id && t.id.indexOf("selecaoNacional-")===0) continue;
      if(t.academy && t.academy.brackets && typeof findPlayerInAcademy==="function" && findPlayerInAcademy(t.id, playerId)) return t.id;
    }
    return null;
  }

  // Convocatória: overall + forma recente + regularidade (pedido explícito do utilizador —
  // "não é só ovr, também é forma" e "e se está a jogar com regularidade"). Mesmo idioma de
  // renewalPriorityScore/retirementProbability (usage=jogos/jornadas já corridas, somado à
  // parte, nunca multiplicado pela forma).
  function nationalSquadScore(p){
    // Jogadores gerados só para completar um plantel de seleção (pool real curta demais —
    // Chile/Angola/Colômbia) nunca jogaram pelo clube nesta época: forma e regularidade ficam
    // neutras (não é o mesmo que p.season inexistente — generatePlaceholderRoster/
    // makeOutfieldPlayer/makeGoalkeeper já inicializam sempre um p.season vazio, por isso o
    // marcador explícito __selecaoFiller é o único sinal fiável de "este jogador é fictício").
    if(p.__selecaoFiller) return overall(p)*3;
    const gamesSoFar = Math.max(1, state.currentRound||state.fixtures.length||1);
    const usage = clamp((p.season&&p.season.jogos||0)/gamesSoFar, 0, 1);
    const notaMedia = p.season&&p.season.notas&&p.season.notas.length ? avg(p.season.notas) : 6;
    return overall(p)*3 + (notaMedia-6)*8 + usage*12;
  }

  // Todos os jogadores reais (de qualquer clube, incl. o do utilizador) cuja nacionalidade
  // corresponda ao código da seleção — reaproveita nationalityFlagCode tal e qual (mesma lógica
  // já usada para a bandeirinha do plantel), para nunca haver duas fontes de verdade sobre
  // "de que país é este jogador".
  function playersForNationCode(code, refDate){
    if(selecaoIsS19Code(code)) return selecaoS19PoolForNation(code, refDate);
    const nation = SELECAO_NATIONS[code];
    if(!nation) return [];
    const found = [];
    Object.values(state.teams).forEach(t=>{
      (t.players||[]).forEach(p=>{ if(nationalityFlagCode(p)===nation.flagCode) found.push(p); });
    });
    return found;
  }

  // Sub-19: elegível quem nasce no ano (data do torneio − 19) ou depois — a regra por ano de
  // nascimento das federações (Sub-19 de 2026: nascidos em 2007 ou depois). Sem data de
  // nascimento, recorre à idade (≤ 18).
  function selecaoS19Eligible(p, refDate){
    if(!p || p.__selecaoFiller) return false;
    const y = (refDate ? new Date(refDate) : state.currentDate).getUTCFullYear();
    if(p.dataNascimento){
      const by = parseInt(String(p.dataNascimento).slice(0,4),10);
      if(!isNaN(by)) return by >= y-19;
    }
    return (p.age||99) <= 18;
  }
  // Jovens (plantéis A/B e escalão Sub-19 da academia) da nação, excluindo quem já está na
  // convocatória sénior desta mesma época (já é internacional A).
  function selecaoS19PoolForNation(code, refDate){
    const nation = selecaoNationOf(code);
    if(!nation) return [];
    const seniorIds = new Set();
    Object.values(state.teams).forEach(t=>{
      if(t.id && t.id.indexOf("selecaoNacional-")===0 && t.id.indexOf("selecaoNacional-s19-")!==0)
        (t.players||[]).forEach(p=>seniorIds.add(p.id));
    });
    const found = [];
    Object.values(state.teams).forEach(t=>{
      if(t.id && t.id.indexOf("selecaoNacional-")===0) return;
      const cand = (t.players||[]).slice();
      if(t.academy && t.academy.brackets && t.academy.brackets.sub19) t.academy.brackets.sub19.players.forEach(p=>cand.push(p));
      cand.forEach(p=>{
        if(seniorIds.has(p.id)) return;
        if(!selecaoS19Eligible(p, refDate)) return;
        if(nationalityFlagCode(p)===nation.flagCode) found.push(p);
      });
    });
    return found;
  }
  // Convocatória Sub-19: o jovem não tem (ou tem pouca) época no clube — valoriza o overall e,
  // ligeiramente, o potencial, a forma e a utilização.
  function selecaoS19Score(p){
    const gamesSoFar = Math.max(1, state.currentRound||(state.fixtures&&state.fixtures.length)||1);
    const usage = clamp((p.season&&p.season.jogos||0)/gamesSoFar, 0, 1);
    const notaMedia = p.season&&p.season.notas&&p.season.notas.length ? avg(p.season.notas) : 6;
    const pot = p.potencial!=null ? p.potencial : (p.potential!=null?p.potential:overall(p));
    return overall(p)*3 + (notaMedia-6)*5 + usage*5 + Math.max(0,(pot-overall(p)))*0.4;
  }
  // Nível de referência dos jogadores gerados para completar plantéis Sub-19: média do overall
  // dos melhores jovens reais do universo, menos um pouco (calculada uma vez por preparação).
  let SELECAO_S19_FILLER_REF = null;
  function selecaoS19ComputeFillerRef(refDate){
    const ovrs = [];
    Object.values(state.teams).forEach(t=>{
      if(t.id && t.id.indexOf("selecaoNacional-")===0) return;
      const cand = (t.players||[]).slice();
      if(t.academy && t.academy.brackets && t.academy.brackets.sub19) t.academy.brackets.sub19.players.forEach(p=>cand.push(p));
      cand.forEach(p=>{ if(selecaoS19Eligible(p, refDate)) ovrs.push(overall(p)); });
    });
    ovrs.sort((a,b)=>b-a);
    const top = ovrs.slice(0, 60);
    SELECAO_S19_FILLER_REF = top.length ? avg(top) : 9;
    return SELECAO_S19_FILLER_REF;
  }

  // Nome mais realista para um jogador fictício desta nação — randomNameForCountry só cobre
  // es/it/fr/de/ch/at/en diretamente; as restantes nações desta lista mapeiam para a língua mais
  // próxima (Argentina/Chile/Colômbia falam espanhol; Angola é lusófona, por isso "pt", que é
  // já o valor por omissão da própria randomNameForCountry).
  function selecaoFillerNameCountry(code){
    if(code==="ar"||code==="cl"||code==="co") return "es";
    return code;
  }
  // Jogador fictício, só para completar um plantel de seleção quando a pool real do país é
  // curta demais (Chile/Angola/Colômbia — ≤4 jogadores reais no universo do jogo). Reaproveita
  // makeOutfieldPlayer/makeGoalkeeper tal e qual (mesmo gerador dos clubes "nuvem") e só corrige
  // a nacionalidade a seguir — essas duas funções não conhecem "ar"/"cl"/"ao"/"co"
  // (normalizeCountryCode/nationalityForCountry cobrem só os países da nuvem europeia), por isso
  // nunca as chamamos com o código real do país, para não gerar `nacionalidade`/`paisOrigem`
  // errados (cairiam sempre em Portugal por omissão). Nunca entra em state.teams — vive só
  // dentro do squad desta edição do torneio.
  function makeSelecaoFillerPlayer(code, idx, pos){
    const nation = selecaoNationOf(code), isS19 = selecaoIsS19Code(code), base0 = selecaoBaseCode(code);
    const rng = makeSeededRng("selecaoFiller|"+code+"|"+pos+"|"+idx+"|"+(state.season||1));
    // Sub-19: nível relativo aos melhores jovens reais (cerca de 2 a 4 pontos abaixo da média).
    const base = isS19
      ? Math.max(6, Math.round((SELECAO_S19_FILLER_REF!=null?SELECAO_S19_FILLER_REF:10) - seededRnd(rng, 2, 4)))
      : seededRnd(rng, 10, 13);
    const nameCountry = selecaoFillerNameCountry(base0);
    const name = randomNameForCountry(nameCountry, rng);
    const id = "selecaoFiller-"+code+"-"+pos+"-"+idx;
    const p = pos==="GR"
      ? makeGoalkeeper(id, 80+idx, name, base, "selecao-filler", "pt")
      : makeOutfieldPlayer(id, 80+idx, name, base, "selecao-filler", "pt");
    p.nacionalidade = nation.nome;
    p.paisOrigem = base0;
    p.__selecaoFiller = true;
    if(isS19){ p.age = seededRnd(rng, 17, 18); }
    return p;
  }

  // Convoca até 10 jogadores (2 GR + 8 de campo, garantindo sempre pelo menos 2 GR mesmo que a
  // pool real não tenha nenhum — pedido explícito do utilizador, 2026-09-27) — ver
  // "Convocatória" no plano aprovado. Devolve a lista pronta (ordenada GR primeiro) e nunca
  // modifica state.teams.
  function pickNationalSquad(code, refDate){
    const isS19 = selecaoIsS19Code(code);
    const scoreFn = isS19 ? selecaoS19Score : nationalSquadScore;
    const pool = playersForNationCode(code, refDate);
    const grReal = pool.filter(p=>p.pos==="GR").sort((a,b)=>scoreFn(b)-scoreFn(a));
    const jReal = pool.filter(p=>p.pos!=="GR").sort((a,b)=>scoreFn(b)-scoreFn(a));
    const GR_TARGET = 2, J_TARGET = 8;
    const gr = grReal.slice(0, GR_TARGET);
    for(let i=gr.length; i<GR_TARGET; i++) gr.push(makeSelecaoFillerPlayer(code, i, "GR"));
    const j = jReal.slice(0, J_TARGET);
    for(let i=j.length; i<J_TARGET; i++) j.push(makeSelecaoFillerPlayer(code, i, "J"));
    return gr.concat(j);
  }

  // =================================================================
  // Fase 2 — Resolução do torneio (grupos + eliminatórias, notícias por jornada)
  // =================================================================

  function selecaoCompetitionName(prova){
    const base = selecaoProvaBase(prova)==="mundial" ? "Campeonato do Mundo" : "Campeonato da Europa";
    if(selecaoProvaIsS19(prova)) return base+" Sub-19";
    return selecaoProvaBase(prova)==="mundial" ? "Campeonato do Mundo (Taça do Mundo)" : base;
  }
  function selecaoCompetitionId(prova){
    const base = selecaoProvaBase(prova)==="mundial" ? "selecoes-mundial" : "selecoes-europeu";
    return selecaoProvaIsS19(prova) ? base+"-s19" : base;
  }
  const SELECAO_PHASE_LABEL = { quartos:"Quartos-de-final", meias:"Meias-finais", final:"Final", terceiro:"3º/4º lugar" };

  // Datas fixas de exibição/corte — factos reais confirmados no plano (Europeu 1-6 de setembro,
  // Mundial 16-21 de setembro, ambas a partir de seasonStartDate(refSeason+1), tal como
  // eliteCupFaseDates já faz para a Elite Cup). 6 dias: 3 jornadas de grupo + QF + SF + Final.
  // Correção (pedido explícito do utilizador, 2026-09-27: "o jogo tem de começar com o campeonato
  // do mundo", "em setembro"): refSeason passa a ser parametrizável (por omissão, state.season,
  // exatamente o comportamento anterior) para que o arranque da carreira (chooseClub, antes de
  // qualquer época existir) possa pedir explicitamente as datas da época 1 (refSeason=0 →
  // seasonStartDate(1)) em vez das da época 2, que é o que sairia de state.season (já a 1 nesse
  // ponto) sem este parâmetro.
  function selecaoTorneioDates(prova, refSeason){
    const season = refSeason!=null ? refSeason : state.season;
    const base = seasonStartDate(season+1);
    // Sub-19: sempre imediatamente antes da prova sénior (6 dias, acaba na véspera do arranque da
    // sénior): Europeu Sub-19 26-31 de agosto (sénior 1-6 set), Mundial Sub-19 10-15 de setembro
    // (sénior 16-21 set).
    const isMundial = selecaoProvaBase(prova)==="mundial";
    const startOffset = selecaoProvaIsS19(prova) ? (isMundial ? 9 : -6) : (isMundial ? 15 : 0);
    const dates = [];
    for(let i=0;i<6;i++) dates.push(addDays(base, startOffset+i));
    return dates;
  }

  function selecaoVirtualTeamId(code){ return "selecaoNacional-"+code; }
  // Objeto "equipa" temporário, no mesmo molde de ensureEuropaNuvemClubes (07g-europa.js) —
  // simulateMatchToCompletion/newMatchState exigem um state.teams[id] real (com .players,
  // .sistema, .mentalidade, .pressao, .reputacao, etc.); uma seleção nacional não é um clube, por
  // isso este objeto é criado só para a duração da resolução do torneio (dentro de um
  // try/finally em resolveSelecaoTournament) e apagado de state.teams logo a seguir — nunca
  // persiste num save.
  function makeVirtualSelecaoTeam(code, squad){
    const nation = selecaoNationOf(code);
    return {
      id: selecaoVirtualTeamId(code), name: nation.nome+(selecaoIsS19Code(code)?" Sub-19":""), color: nation.color, tier: 1,
      divisaoAtual: "selecao-nacional", zona: null, pais: selecaoBaseCode(code),
      pavilhao: null, cidadePavilhao: null,
      nuvemEuropeia: false, selecaoNacional: true,
      equipaPrincipalId: null, equipaBId: null,
      reputacao: 70, reputacaoPontos: 70, reputacaoClube: 70,
      desempenhoRecente: 50, capacidadeFinanceira: 50, massaAdepta: 50,
      condicoesTreino: "Boas",
      players: squad,
      sistema: "3-1", mentalidade: "equilibrado", pressao: "media",
      stats: { J:0, V:0, E:0, D:0, GM:0, GS:0, Pts:0 },
      academy: null,
    };
  }

  // Um jogo da seleção — reaproveita os primitivos do motor tal e qual (newMatchState/
  // runMatchTicks/buildMatchSummary/finalizePlayerStats, o mesmo caminho de
  // simulateMatchToCompletion, 06-motor-jogo.js), com duas diferenças cruciais:
  //
  // 1) Vantagem de casa do país organizador (pedido explícito do utilizador: "os jogos são em
  //    campo neutro excepto para a equipa do país organizador que tem a vantagem casa (mesmo não
  //    estando à esquerda no jogo)") — quando nenhuma das duas seleções é o anfitrião, o jogo é em
  //    campo neutro (neutralVenue=true, ninguém tem bónus); quando o anfitrião joga e calha do
  //    lado "away" do sorteio/emparelhamento, troca-se qual dos dois ids entra como "home" na
  //    chamada ao motor (só para o cálculo de força) — o resultado é depois remapeado de volta
  //    para a perspetiva do fixture original (fixtureHome/fixtureAway), para a classificação e as
  //    notícias nunca verem essa troca.
  // 2) Snapshot/restauro das estatísticas de CLUBE dos jogadores reais — finalizePlayerStats
  //    mutila season/moral/satisfacao/participacaoCompeticoes/__recentPlayed (todos campos do
  //    clube, nunca da seleção); sem isto, jogar pela seleção contaminaria o registo de época do
  //    jogador no seu clube. A ÚNICA mutação que fica é a condição física (fadiga) — jogar pela
  //    seleção cansa mesmo, de propósito (é o que torna a convocatória um custo real para o
  //    utilizador, tal como suspensão/lesão). Jogadores fictícios (__selecaoFiller) não têm
  //    registo de clube nenhum a proteger — ficam de fora do snapshot.
  function resolveSelecaoMatch(fixtureHomeCode, fixtureAwayCode, hostCode, isPlayoff, competitionId){
    const homeTeamId = selecaoVirtualTeamId(fixtureHomeCode);
    const awayTeamId = selecaoVirtualTeamId(fixtureAwayCode);
    const neutralVenue = (hostCode !== fixtureHomeCode && hostCode !== fixtureAwayCode);
    const hostIsAway = !neutralVenue && hostCode===fixtureAwayCode;
    const engineHomeId = hostIsAway ? awayTeamId : homeTeamId;
    const engineAwayId = hostIsAway ? homeTeamId : awayTeamId;

    const allSquadPlayers = state.teams[homeTeamId].players.concat(state.teams[awayTeamId].players);
    const edM = selecaoEdicaoDeCompeticao(competitionId);
    const isS19 = selecaoIsS19Code(fixtureHomeCode);
    // Resolução "em diferido" (Europeu Sub-19, resolvido no salto do defeso para 1 de setembro):
    // a fadiga do jogo não pode ficar, porque nenhum dia passa até à época seguinte.
    const restoreCondicao = !!(edM && edM.catchUp);
    const snapshots = new Map();
    allSquadPlayers.forEach(p=>{
      if(p.__selecaoFiller) return;
      snapshots.set(p.id, {
        season: JSON.parse(JSON.stringify(p.season)),
        moral: p.moral, satisfacao: p.satisfacao,
        participacaoCompeticoes: JSON.parse(JSON.stringify(p.participacaoCompeticoes||{})),
        recentPlayed: (p.__recentPlayed||[]).slice(),
        // Correção (verificação final, 2026-09-26): o motor de jogo também pode marcar
        // suspensoJogos (cartão vermelho, 06-motor-jogo.js:1167) e diasLesao (lesão em jogo,
        // 06-motor-jogo.js:529/537/567) diretamente no jogador, fora de finalizePlayerStats —
        // sem isto, um cartão/lesão apanhado ao serviço da seleção prendia o jogador do CLUBE
        // (suspensão/lesão de clube) por algo que aconteceu num jogo da seleção. Tal como os
        // outros campos de época, são snapshot aqui e repostos no finally — só p.condicao (o
        // cansaço de jogar) fica mesmo por conta do clube, de propósito (é o que torna a
        // convocatória um custo real).
        suspensoJogos: p.suspensoJogos||0, diasLesao: p.diasLesao||0,
        condicao: p.condicao,
      });
    });

    let result;
    try {
      const ctx = newMatchState(engineHomeId, engineAwayId, !!isPlayoff, neutralVenue, false, competitionId);
      let guard = 0;
      while(!ctx.finished && guard < 3000){ runMatchTicks(ctx); guard++; }
      const summary = buildMatchSummary(ctx);
      finalizePlayerStats(ctx, summary.mvp);
      // Internacionalizações/golos internacionais — só para jogadores reais que efetivamente
      // entraram em campo (summary.players já só contém quem jogou, ver buildMatchSummary) e
      // nunca para os fictícios (__selecaoFiller).
      summary.players.forEach(row=>{
        const p = allSquadPlayers.find(x=>x.id===row.id);
        if(!p || p.__selecaoFiller) return;
        if(isS19){
          // Contadores à parte: as internacionalizações Sub-19 não contam como caps de seleção A.
          p.internacionalizacoesSub19 = (p.internacionalizacoesSub19||0) + 1;
          p.golosSub19 = (p.golosSub19||0) + (row.goals||0);
        } else {
          p.internacionalizacoes = (p.internacionalizacoes||0) + 1;
          p.golosInternacional = (p.golosInternacional||0) + (row.goals||0);
        }
        // Reputação e valor de mercado (pedido explícito do utilizador, 2026-09-27: "jogar na
        // sselecções tem de aumentar os valores de mercado e reputação") — bónus direto e
        // IMEDIATO a reputacaoJogador, no mesmo espírito de grantSeasonAward
        // (08-evolucao-jogadores.js): sem isto, jogar pela seleção só se refletiria em
        // reputacaoJogador meses depois, na mistura de closeCompletedSeasonPlayerStats() no fim
        // da época (que já lê internacionalizacoes/golosInternacional via
        // computePlayerReputation, mas só nessa altura). playerMarketValue (04-financas.js)
        // deriva sempre, ao vivo, de reputacaoJogador — basta subir este campo para o valor de
        // mercado do jogador subir de imediato também. Jitter determinístico por jogador+data
        // (nunca um valor fixo), maior por golo marcado.
        const repRng = makeSeededRng(`${p.id}|selecao-rep|${fixtureHomeCode}|${fixtureAwayCode}|${state.currentDate?state.currentDate.getTime():0}`);
        const repBump = (seededRndFloat(repRng, 0.3, 0.9) + (row.goals||0)*0.4) * (isS19 ? 0.6 : 1);
        p.reputacaoJogador = clamp((p.reputacaoJogador||0)+repBump, 0, 100);
        // Estatísticas e prémios da prova (pedido explícito do utilizador, 2026-09-27: "também
        // deve haver estatísticas e prêmios nos mundiais e europeus") — acumulado à parte de
        // player.participacaoCompeticoes (essa é sempre reposta no finally acima, de propósito,
        // para nunca contaminar as estatísticas de CLUBE do jogador) — vive só em
        // ed.playerStats, o estado próprio desta edição do torneio, e é lido em
        // selecaoAwardEntries() (mais abaixo) para calcular Melhor Marcador/Guarda-Redes/Jogador
        // no fim do torneio, tal como computeCompetitionAwards já faz para as competições de
        // clube (08-evolucao-jogadores.js) — reaproveitada tal e qual.
        const ed = edM;
        if(ed){
          if(!ed.playerStats) ed.playerStats = {};
          const acc = ed.playerStats[p.id] || {jogos:0, golos:0, assistencias:0, golosSofridos:0, mvp:0, notas:[]};
          acc.jogos += 1;
          acc.golos += row.goals||0;
          acc.assistencias += row.assists||0;
          acc.golosSofridos += row.golosSofridos||0;
          if(summary.mvp && summary.mvp.id===p.id) acc.mvp += 1;
          acc.notas.push(row.rating);
          ed.playerStats[p.id] = acc;
        }
      });
      result = {
        homeScore: hostIsAway ? ctx.score.away : ctx.score.home,
        awayScore: hostIsAway ? ctx.score.home : ctx.score.away,
        soWinner: ctx.soWinner ? (hostIsAway ? (ctx.soWinner==="home"?"away":"home") : ctx.soWinner) : null,
      };
    } finally {
      allSquadPlayers.forEach(p=>{
        if(p.__selecaoFiller) return;
        const snap = snapshots.get(p.id);
        if(!snap) return;
        p.season = snap.season; p.moral = snap.moral; p.satisfacao = snap.satisfacao;
        p.participacaoCompeticoes = snap.participacaoCompeticoes;
        p.__recentPlayed = snap.recentPlayed;
        p.suspensoJogos = snap.suspensoJogos; p.diasLesao = snap.diasLesao;
        if(restoreCondicao) p.condicao = snap.condicao;
      });
    }
    return result;
  }

  // Classificação do grupo (pontos, depois diferença de golos, depois golos marcados) — os
  // .stats de cada seleção são mantidos por applyStandings (06-motor-jogo.js), reaproveitado tal
  // e qual (já trata Pts/GM/GS/recentResults/registerTreinadorMatchResult de forma defensiva,
  // confirmado seguro numa equipa virtual sem treinador nem competição real associada).
  function sortSelecaoGroupCodes(codes){
    return codes.slice().sort((a,b)=>{
      const sa = state.teams[selecaoVirtualTeamId(a)].stats, sb = state.teams[selecaoVirtualTeamId(b)].stats;
      if(sb.Pts !== sa.Pts) return sb.Pts - sa.Pts;
      const gda = sa.GM-sa.GS, gdb = sb.GM-sb.GS;
      if(gdb !== gda) return gdb - gda;
      return sb.GM - sa.GM;
    });
  }
  function selecaoGroupPosLabel(code, letter, sortedCodes){
    return (sortedCodes.indexOf(code)+1) + "º" + letter;
  }

  // Mesmo formato/estilo .jr-row já usado pela jornada do utilizador (buildJornadaResultsNews,
  // 06-motor-jogo.js) — só troca .jr-team-link (botão para a ficha do clube) por .jr-nation
  // (texto+bandeira, sem afeto de clicável — uma seleção não tem ficha de clube para abrir).
  function selecaoRowHtml(fx, resultMode, posHome, posAway){
    const score = resultMode
      ? (fx.played ? `${fx.homeScore} - ${fx.awayScore}${fx.soWinner?' <span style="font-size:9px;">(g.p.)</span>':''}` : "—")
      : "vs";
    return `<div class="jr-row">
      <span class="jr-pos">${posHome||""}</span>
      ${selecaoNationLinkHtml(fx.home, "jr-nation jr-home")}
      <span class="jr-score">${score}</span>
      ${selecaoNationLinkHtml(fx.away, "jr-nation jr-away", true)}
      <span class="jr-pos">${posAway||""}</span>
    </div>`;
  }

  // Pedido explícito do utilizador: "os jogos são para aparecerem no e-mail... tipo jornada 1
  // grupo A espanha vs Itália Portugal vs França grupo B: ...." — as linhas dos dois grupos
  // juntas, sob um cabeçalho por grupo, numa única notícia (antevisão antes da jornada, resultados
  // depois — mesmo padrão da jornada da liga do utilizador).
  function selecaoGroupNewsRows(groupA, groupB, roundFixturesA, roundFixturesB, resultMode){
    const sortedA = sortSelecaoGroupCodes(groupA), sortedB = sortSelecaoGroupCodes(groupB);
    const rowsFor = (fixtures, sorted, letter) => fixtures.map(fx=>selecaoRowHtml(fx, resultMode,
      selecaoGroupPosLabel(fx.home, letter, sorted), selecaoGroupPosLabel(fx.away, letter, sorted))).join("");
    return `<div class="jr-group-header">Grupo A</div>${rowsFor(roundFixturesA, sortedA, "A")}`+
      `<div class="jr-group-header">Grupo B</div>${rowsFor(roundFixturesB, sortedB, "B")}`;
  }
  function pushSelecaoGroupNews(prova, roundIdx, groupA, groupB, roundFixturesA, roundFixturesB, date, resultMode){
    const rows = selecaoGroupNewsRows(groupA, groupB, roundFixturesA, roundFixturesB, resultMode);
    const label = resultMode ? "Resultados" : "Antevisão";
    pushNews(date, rows, "jogo", `${label} — Jornada ${roundIdx+1} de ${selecaoCompetitionName(prova)} (${fmtDateShort(date)})`);
  }

  // Uma ronda eliminatória (quartos/meias/final/3º-4º lugar) — antevisão e resultados, agora em
  // duas funções separadas (2026-09-27, correção pedida pelo utilizador: "a antevisão está a vir
  // depois dos resultados") em vez de uma só que publicava as duas notícias na mesma data — ver
  // pushSelecaoBracketPreview/resolveSelecaoBracketResults, chamadas em dias diferentes por
  // processSelecoesForCurrentDate, tal como a jornada da liga do utilizador
  // (buildJornadaPreviewNews um dia antes, buildJornadaResultsNews no próprio dia). seedLabels
  // (opcional) mostra a posição de grupo de cada seleção nos quartos (ex. "1ºA"/"4ºB"),
  // refletindo o cruzamento pedido pelo utilizador. isPlayoff=true em resolveSelecaoMatch:
  // empate resolve-se sempre em prolongamento + grandes penalidades, tal como qualquer outra
  // eliminatória do jogo (ver runShootout em 06-motor-jogo.js).
  function pushSelecaoBracketPreview(prova, phaseKey, pairs, date, seedLabels){
    const labelFor = code => (seedLabels && seedLabels[code]) || "";
    const phaseName = SELECAO_PHASE_LABEL[phaseKey] || phaseKey;
    const rows = pairs.map(([home,away])=>selecaoRowHtml({home,away,played:false}, false, labelFor(home), labelFor(away))).join("");
    pushNews(date, rows, "jogo", `Antevisão — ${phaseName} de ${selecaoCompetitionName(prova)} (${fmtDateShort(date)})`);
  }
  function resolveSelecaoBracketResults(prova, phaseKey, pairs, hostCode, date, competitionId, seedLabels){
    const fixtures = pairs.map(([home,away])=>({home,away,played:false,homeScore:0,awayScore:0,soWinner:null}));
    const labelFor = code => (seedLabels && seedLabels[code]) || "";
    const phaseName = SELECAO_PHASE_LABEL[phaseKey] || phaseKey;
    fixtures.forEach(fx=>{
      const r = resolveSelecaoMatch(fx.home, fx.away, hostCode, true, competitionId);
      fx.played=true; fx.homeScore=r.homeScore; fx.awayScore=r.awayScore; fx.soWinner=r.soWinner;
      fx.winnerCode = r.homeScore!==r.awayScore ? (r.homeScore>r.awayScore?fx.home:fx.away) : (r.soWinner==="home"?fx.home:fx.away);
      fx.loserCode = fx.winnerCode===fx.home ? fx.away : fx.home;
    });
    const rows = fixtures.map(fx=>selecaoRowHtml(fx, true, labelFor(fx.home), labelFor(fx.away))).join("");
    pushNews(date, rows, "jogo", `Resultados — ${phaseName} de ${selecaoCompetitionName(prova)} (${fmtDateShort(date)})`);
    return fixtures;
  }

  // Notícia de sorteio/anfitrião — sempre publicada (mesmo sem nenhum jogador do clube do
  // utilizador envolvido), mostra os dois grupos e quem organiza esta edição.
  function pushSelecaoDrawNews(prova, groupA, groupB, hostCode, date){
    const listHtml = codes => codes.map(c=>`<div>${selecaoNationLinkHtml(c)}</div>`).join("");
    const text = `<strong>País organizador:</strong> ${selecaoNationLinkHtml(hostCode)} `+
      `(vantagem de jogar em casa nesta edição, mesmo quando não é a equipa "da casa" no confronto)<br><br>`+
      `<strong>Grupo A</strong>${listHtml(groupA)}<br><strong>Grupo B</strong>${listHtml(groupB)}`;
    pushNews(date, text, "jogo", `Sorteio — ${selecaoCompetitionName(prova)} (${fmtDateShort(date)})`);
  }
  // Notícia de convocatória — dispara SEMPRE que há convocatória para uma prova, dizendo sempre
  // se saíram ou não jogadores do PRÓPRIO clube do utilizador (pedido explícito do utilizador,
  // 2026-09-27: "tem de sair uma notícia... dizendo se foram convocados jogadores da equipa do
  // utilizador" — antes só disparava quando havia pelo menos um, ficando silenciosa nas
  // convocatórias sem qualquer jogador do clube, o que o utilizador deixou de querer).
  function pushSelecaoConvocationNews(prova, allCodes, date){
    const userTeam = state.teams[state.userTeamId];
    const meusConvocados = [];
    if(userTeam){
      allCodes.forEach(code=>{
        state.teams[selecaoVirtualTeamId(code)].players.forEach(p=>{
          if(p.__selecaoFiller) return;
          if(userTeam.players.some(x=>x.id===p.id) || (typeof findPlayerInAcademy==="function" && findPlayerInAcademy(userTeam.id, p.id))) meusConvocados.push({p, code});
        });
      });
    }
    const corpo = meusConvocados.length
      ? `${meusConvocados.length} jogador(es) do ${userTeam.name} foram convocados para o ${selecaoCompetitionName(prova)}:<br>`+
        meusConvocados.map(({p,code}) => `${playerLinkHtml(state.userTeamId,p)} — Seleção de ${selecaoNationLinkHtml(code)}${selecaoIsS19Code(code)?" (Sub-19)":""}`).join("<br>")
      : `Nenhum jogador do ${userTeam?userTeam.name:"teu clube"} foi convocado desta vez para o ${selecaoCompetitionName(prova)}.`;
    pushNews(date, corpo, "jogo", `Convocatórias — ${selecaoCompetitionName(prova)}`);
  }
  function pushSelecaoChampionNews(prova, championCode, runnerUpCode, date){
    const champ = selecaoNationOf(championCode);
    pushNews(date, `<strong>${selecaoNationLinkHtml(championCode)}</strong> conquistou o ${selecaoCompetitionName(prova)}, batendo ${selecaoNationLinkHtml(runnerUpCode)} na final.`,
      "jogo", `${champ.nome} é campeão do ${selecaoCompetitionName(prova)}`);
  }

  // =================================================================
  // Estatísticas e prémios individuais da prova (pedido explícito do utilizador, 2026-09-27:
  // "também deve haver estatísticas e prêmios nos mundiais e europeus")
  // =================================================================

  // Reconstrói, a partir de ed.playerStats (acumulado jogo a jogo em resolveSelecaoMatch), a
  // lista de entradas no formato que computeCompetitionAwards (08-evolucao-jogadores.js) já
  // espera para as competições de clube — {player, team, jogos, golos, assistencias, mvp,
  // notas, golosSofridos} — reaproveitando tal e qual a mesma lógica de seleção de Melhor
  // Marcador/Guarda-Redes/Jogador, em vez de duplicar os critérios aqui. team é sempre o clube
  // REAL atual do jogador (teamIdForRealPlayer, nunca uma equipa virtual de seleção) — jogadores
  // fictícios (__selecaoFiller) nunca entram em ed.playerStats, por isso nunca aparecem aqui.
  function selecaoAwardEntries(ed){
    return Object.keys(ed.playerStats||{}).map(pid=>{
      const teamId = teamIdForRealPlayer(pid);
      if(!teamId) return null;
      const team = state.teams[teamId];
      const player = team && (team.players.find(x=>x.id===pid) || (typeof findPlayerInAcademy==="function" ? findPlayerInAcademy(teamId, pid) : null));
      if(!player) return null;
      const acc = ed.playerStats[pid];
      return { player, team, jogos:acc.jogos, golos:acc.golos, assistencias:acc.assistencias, golosSofridos:acc.golosSofridos, mvp:acc.mvp, notas:acc.notas.slice() };
    }).filter(Boolean);
  }

  // Efeitos de um prémio individual da prova — mesmo espírito de grantSeasonAward
  // (08-evolucao-jogadores.js: título, reputação do jogador e do clube, valorização de mercado,
  // tudo com jitter determinístico), mas escrita à parte porque grantSeasonAward lê
  // seasonLabel(state.season) diretamente — ao correr no dia em que a final se resolve (dias
  // reais depois de beginDefeso ter já incrementado state.season para a época seguinte), isso
  // desalinharia a época do prémio da época real do torneio (ed.season+1, a mesma usada no
  // título de campeão e em selecoesHistorico). Usa sempre o nível A (o mais prestigiado) — um
  // Mundial/Europeu é, por definição, o patamar mais alto do jogo.
  function grantSelecaoIndividualAward(entry, ed, awardType, label){
    const { player, team } = entry;
    const seasonLbl = seasonLabel(ed.season+1);
    const compLabel = selecaoCompetitionName(ed.prova);
    const tituloTexto = `${label} — ${compLabel} ${seasonLbl}`;
    if(!Array.isArray(player.titulos)) player.titulos=[];
    if(!player.titulos.includes(tituloTexto)) player.titulos.push(tituloTexto);

    const cfg = selecaoProvaIsS19(ed.prova) ? SEASON_PRIZE_TIER_CONFIG.C : SEASON_PRIZE_TIER_CONFIG.A;
    const repRng = makeSeededRng(`${player.id}|selecao-premio-rep|${ed.competitionId}|${seasonLbl}|${awardType}`);
    const repBump = seededRndFloat(repRng, cfg.repJogador[0], cfg.repJogador[1]);
    player.reputacaoJogador = clamp((player.reputacaoJogador||0)+repBump, 0, 100);

    if(team){
      const repClubeRng = makeSeededRng(`${team.id}|selecao-premio-rep-clube|${ed.competitionId}|${seasonLbl}|${awardType}`);
      const repClubeBump = seededRndFloat(repClubeRng, cfg.repClube[0], cfg.repClube[1]);
      const before = team.reputacaoPontos!=null ? team.reputacaoPontos : normalizeClubReputation(team.reputacao, team);
      const after = clamp(before+repClubeBump, 5, 99);
      team.reputacaoPontos = after;
      team.reputacao = reputationFromPoints(after);
    }

    const valorRange = awardType==="jogador" ? cfg.valorJogador : cfg.valorOutros;
    const valorRng = makeSeededRng(`${player.id}|selecao-premio-valor|${ed.competitionId}|${seasonLbl}|${awardType}`);
    const pct = seededRndFloat(valorRng, valorRange[0], valorRange[1]);
    const valorAtual = playerMarketValue(player, team);
    player.valorPremioBonus = (player.valorPremioBonus||0) + Math.round(valorAtual*pct);
  }

  // Notícia única com os 3 prémios individuais (sempre publicada, tal como o campeão — uma
  // seleção pode não ter nenhum jogador do clube do utilizador e a notícia continua a sair).
  function pushSelecaoAwardsNews(ed, marcador, guardaRedes, jogador, date){
    if(!marcador && !guardaRedes && !jogador) return;
    const rows = [];
    if(marcador) rows.push(`<strong>Melhor Marcador:</strong> ${playerLinkHtml(marcador.team.id,marcador.player)} (${teamLinkHtml(marcador.team.id)}) — ${marcador.golos} golo(s)`);
    if(guardaRedes) rows.push(`<strong>Melhor Guarda-Redes:</strong> ${playerLinkHtml(guardaRedes.team.id,guardaRedes.player)} (${teamLinkHtml(guardaRedes.team.id)})`);
    if(jogador) rows.push(`<strong>Melhor Jogador:</strong> ${playerLinkHtml(jogador.team.id,jogador.player)} (${teamLinkHtml(jogador.team.id)})`);
    pushNews(date, rows.join("<br>"), "sistema", `Prémios Individuais — ${selecaoCompetitionName(ed.prova)} (${seasonLabel(ed.season+1)})`);
  }

  // Cópia simples de uma eliminatória resolvida, sem nenhuma referência a state.teams — o que vai
  // para state.selecoesHistorico (ver mais abaixo), para sobreviver à eliminação das equipas
  // virtuais no finally e a um ciclo save/load via compactSaveClone.
  function selecaoArchiveFixture(fx){
    return { home:fx.home, away:fx.away, homeScore:fx.homeScore, awayScore:fx.awayScore, soWinner:fx.soWinner, winnerCode:fx.winnerCode, loserCode:fx.loserCode, played:true };
  }

  // Correção (pedido explícito do utilizador, 2026-09-27: "como é que estou no dia 1 e recebo
  // noticias do dia 16 e 19? o jogo tem de começar com a noticia da convocatória... depois vemos
  // as noticias dos jogos"): resolveSelecaoTournament resolvia o torneio inteiro (sorteio,
  // convocatória, 3 jornadas de grupo, quartos, meias, final/3º-4º lugar) numa única chamada
  // síncrona, publicando TODAS as notícias de uma vez, cada uma já com a sua data futura fixa
  // (dates[0..5], ex. 16-21 de setembro) — mas sem qualquer gate por state.currentDate, tudo
  // aparecia na caixa de entrada logo no dia 1. Este ficheiro passa a seguir exatamente o mesmo
  // padrão diário já usado pela Elite Cup/Europa/Taça de Portugal (ver processEliteCupForCurrentDate,
  // 07d-elite-cup.js, e processPhaseFiveFinalsForCurrentDate, 07-playoff.js): a edição é preparada
  // e ANUNCIADA (sorteio + convocatória, só) no dia em que arranca, e cada jornada/eliminatória só
  // se resolve e publica a sua notícia quando o calendário chega mesmo à sua data — via
  // processSelecoesForCurrentDate(), chamada dia a dia a partir de processPhaseFiveFinalsForCurrentDate().
  //
  // Estado próprio (mesmo padrão de state.eliteCup/state.europa): state.selecoes.edicao guarda a
  // edição em curso (grupos, calendário, datas, fases já resolvidas) entre chamadas — as equipas
  // virtuais só são apagadas quando a edição termina (final resolvida), nunca antes, para
  // sobreviverem aos vários dias que a resolução leva agora a demorar.

  // Prepara uma nova edição (sorteio, convocatória — LÊ a forma da época que está a terminar,
  // por isso tem de correr antes de closeCompletedSeasonPlayerStats() apagar player.season — e o
  // calendário completo dos 2 grupos) mas NÃO publica nenhuma notícia nem resolve nenhum jogo
  // ainda — isso só acontece em announceSelecoesEdicaoIfPending()/processSelecoesForCurrentDate(),
  // quando o calendário realmente lá chegar. refSeason: ver selecaoTorneioDates — por omissão
  // state.season (chamada no início de beginDefeso, fim de cada época normal), explícito=0 na
  // única chamada feita a partir de chooseClub() (arranque da carreira).
  function prepareSelecoesEdicaoForNewSeason(refSeason){
    if(!state.selecoesProxima) state.selecoesProxima = "mundial";
    const prova = state.selecoesProxima;
    state.selecoesProxima = prova==="mundial" ? "europeu" : "mundial";
    const seedRanking = (state.selecoesRanking && state.selecoesRanking[prova]) || selecaoNationCodesFor(prova);
    const groupA = seedRanking.slice(0,4), groupB = seedRanking.slice(4,8);
    const season = refSeason!=null ? refSeason : state.season;
    const dates = selecaoTorneioDates(prova, season);
    const allCodes = groupA.concat(groupB);
    const competitionId = selecaoCompetitionId(prova);
    const hostRng = makeSeededRng("selecaoHost|"+prova+"|"+season);
    const hostCode = allCodes[seededRnd(hostRng, 0, allCodes.length-1)];

    // Última convocatória de cada seleção (pedido do utilizador, 2026-09-27: "as seleções têm de
    // ser clicáveis e tem de aparecer a lista dos jogadores da última convocatória. Só muda na
    // convocatória a seguir") — guardado à parte das equipas virtuais para sobreviver entre
    // edições e a um ciclo save/load. Cada nação só é reescrita quando volta a ser convocada.
    if(!state.selecoesUltimaConvocatoria) state.selecoesUltimaConvocatoria = {};
    // Selecção Nacional — Acumulação de Cargo (2026-10-03): se o utilizador for seleccionador de
    // alguma das nações desta edição, a CONVOCATÓRIA DELE não é escolhida aqui — fica pendente
    // (state.pendingNationalSquadPick) até ele a escolher à mão no novo modal
    // (#selecaoConvocatoriaManualModal, 09-fluxo-epoca.js), que termina chamando
    // finalizeSelecaoNationSquad com a squad escolhida. As outras 7 nações seguem o algoritmo
    // automático de sempre (pickNationalSquad), sem qualquer alteração.
    const g = ensureManagerCareer();
    const userSelecaoCode = g.selecaoAtual && allCodes.includes(g.selecaoAtual.code) ? g.selecaoAtual.code : null;
    allCodes.forEach(code=>{
      if(code === userSelecaoCode) return; // tratado depois, à parte — ver pendingNationalSquadPick
      finalizeSelecaoNationSquad(code, pickNationalSquad(code), prova, season, dates);
    });

    state.selecoes = state.selecoes || {};
    state.selecoes.edicao = {
      prova, season, hostCode, competitionId, dates,
      groupA, groupB, allCodes,
      fixturesA: generateFixtures(groupA).slice(0, groupA.length-1),
      fixturesB: generateFixtures(groupB).slice(0, groupB.length-1),
      roundsPlayed: 0,
      qfFixtures: null, sfFixtures: null, thirdFixtures: null, finalFixtures: null,
      sortedA: null, sortedB: null, seedLabels: null,
      announced: false,
      // Estatísticas da prova, acumuladas jogo a jogo em resolveSelecaoMatch — ver comentário
      // aí. Chave = id do jogador real; nunca inclui jogadores fictícios (__selecaoFiller).
      playerStats: {},
    };
    if(userSelecaoCode){
      state.pendingNationalSquadPick = { code: userSelecaoCode, prova, season };
    }
    // Sub-19 (2026-10-14): a prova do mesmo nome, imediatamente antes da sénior.
    prepareSelecoesSub19ForNewSeason(season, prova);
  }

  // Prepara a edição Sub-19 correspondente à sénior acabada de preparar (mesma prova, mesma época).
  // Corre sempre DEPOIS da sénior, para excluir da pool Sub-19 quem já foi convocado para a sénior.
  // Plantel: 2 GR + 8 jogadores de campo, da pool de jovens (plantéis A/B + escalão Sub-19 da
  // academia) da nação; lugares em falta preenchidos com jogadores gerados (selecaoFiller).
  function prepareSelecoesSub19ForNewSeason(season, seniorProva){
    const prova = seniorProva + "-s19";
    const dates = selecaoTorneioDates(prova, season);
    const ranking = state.selecoesRanking && state.selecoesRanking[prova];
    const seedRanking = (Array.isArray(ranking) && ranking.length===8 && ranking.every(selecaoIsS19Code)) ? ranking : selecaoNationCodesFor(prova);
    const groupA = seedRanking.slice(0,4), groupB = seedRanking.slice(4,8);
    const allCodes = groupA.concat(groupB);
    const competitionId = selecaoCompetitionId(prova);
    const hostRng = makeSeededRng("selecaoHost|"+prova+"|"+season);
    const hostCode = allCodes[seededRnd(hostRng, 0, allCodes.length-1)];
    if(!state.selecoesUltimaConvocatoria) state.selecoesUltimaConvocatoria = {};
    selecaoS19ComputeFillerRef(dates[0]);
    allCodes.forEach(code=>{
      finalizeSelecaoNationSquad(code, pickNationalSquad(code, dates[0]), prova, season, dates);
    });
    state.selecoes = state.selecoes || {};
    state.selecoes.edicaoS19 = {
      prova, season, hostCode, competitionId, dates,
      groupA, groupB, allCodes, s19: true,
      fixturesA: generateFixtures(groupA).slice(0, groupA.length-1),
      fixturesB: generateFixtures(groupB).slice(0, groupB.length-1),
      roundsPlayed: 0,
      qfFixtures: null, sfFixtures: null, thirdFixtures: null, finalFixtures: null,
      sortedA: null, sortedB: null, seedLabels: null,
      announced: false,
      playerStats: {},
    };
  }

  // Cria a equipa virtual de UMA nação a partir de uma squad já escolhida (automática ou manual),
  // regista a última convocatória, marca a indisponibilidade dos jogadores reais para o clube
  // (convocadoSelecaoAte), e — só quando esta é a nação do PRÓPRIO utilizador
  // (state.gestor.selecaoAtual) — aplica o seu perfil táctico (treinadorCultura) à equipa
  // (selecaoTreinadorCulturaFromGestor, 08c-staff-treinadores.js): newMatchState já lê esse campo
  // tal e qual como faz para um clube, sem qualquer outra alteração ao motor. Extraído para ser
  // partilhado entre o loop automático (acima) e a confirmação da convocatória manual
  // (09-fluxo-epoca.js).
  function finalizeSelecaoNationSquad(code, squad, prova, season, dates){
    state.teams[selecaoVirtualTeamId(code)] = makeVirtualSelecaoTeam(code, squad);
    state.selecoesUltimaConvocatoria[code] = {
      prova, season: season, seasonLabel: seasonLabel(season+1),
      jogadores: squad.map(p=>({
        id: p.id, nome: p.name, pos: p.pos,
        teamId: p.__selecaoFiller ? null : teamIdForRealPlayer(p.id),
        filler: !!p.__selecaoFiller,
      })),
    };
    state.teams[selecaoVirtualTeamId(code)].players.forEach(p=>{
      if(p.__selecaoFiller) return;
      const ate = new Date(dates[5]);
      if(!p.convocadoSelecaoAte || new Date(p.convocadoSelecaoAte) < ate) p.convocadoSelecaoAte = ate;
    });
    const g = ensureManagerCareer();
    if(g.selecaoAtual && g.selecaoAtual.code === code){
      state.teams[selecaoVirtualTeamId(code)].treinadorCultura = selecaoTreinadorCulturaFromGestor(g);
    }
  }

  // Chamada pelo modal de convocatória manual (09-fluxo-epoca.js) depois de o utilizador escolher
  // os jogadores — completa, da mesma forma que pickNationalSquad, qualquer lugar deixado por
  // preencher (nunca menos de 2 GR + 8 campo no total, mesma regra do algoritmo automático) e
  // termina a preparação da edição que ficou pendente em prepareSelecoesEdicaoForNewSeason.
  function confirmManualSelecaoSquad(selectedPlayerIds){
    const pending = state.pendingNationalSquadPick;
    if(!pending) return;
    const code = pending.code;
    const pool = playersForNationCode(code);
    const chosen = selectedPlayerIds.map(id=>pool.find(p=>p.id===id)).filter(Boolean);
    const gr = chosen.filter(p=>p.pos==="GR").slice(0,2);
    const j = chosen.filter(p=>p.pos!=="GR").slice(0,8);
    for(let i=gr.length;i<2;i++) gr.push(makeSelecaoFillerPlayer(code, i, "GR"));
    for(let i=j.length;i<8;i++) j.push(makeSelecaoFillerPlayer(code, i, "J"));
    const squad = gr.concat(j);
    const ed = state.selecoes && state.selecoes.edicao;
    const dates = ed ? ed.dates : selecaoTorneioDates(pending.prova, pending.season);
    finalizeSelecaoNationSquad(code, squad, pending.prova, pending.season, dates);
    state.pendingNationalSquadPick = null;
    if(typeof announceSelecoesEdicaoIfPending==="function") announceSelecoesEdicaoIfPending();
  }

  // Publica o sorteio + convocatória (só) da edição já preparada, datados de state.currentDate —
  // pedido explícito do utilizador: "o jogo tem de começar com a noticia da convocatória... depois
  // vemos as noticias dos jogos". Chamada uma vez, assim que state.currentDate chega mesmo ao dia
  // em que a pré-época começa (logo a seguir a prepareSelecoesEdicaoForNewSeason() em chooseClub();
  // depois do salto para seasonStartDate(state.season+1) em beginDefeso, ver esse ficheiro) — nunca
  // antes, para a data da notícia corresponder sempre ao "hoje" real do jogo, nunca a uma data
  // futura ainda não vivida.
  function announceSelecoesEdicaoIfPending(){
    const sel = state.selecoes || {};
    // Sub-19 primeiro (acontece antes da sénior). Se todo o torneio já ficou no passado (Europeu
    // Sub-19, 26-31 de agosto, quando o jogo salta do defeso para 1 de setembro), resolve-se agora,
    // dia a dia, com as notícias datadas dos dias certos.
    const eds = sel.edicaoS19;
    if(eds && !eds.announced){
      if(new Date(eds.dates[5]) < state.currentDate) selecoesSub19CatchUp(eds);
      else {
        pushSelecaoDrawNews(eds.prova, eds.groupA, eds.groupB, eds.hostCode, state.currentDate);
        pushSelecaoConvocationNews(eds.prova, eds.allCodes, state.currentDate);
        eds.announced = true;
      }
    }
    const ed = sel.edicao;
    if(!ed || ed.announced) return;
    // Selecção Nacional — Acumulação de Cargo (2026-10-03): enquanto a convocatória manual do
    // utilizador ainda não foi confirmada (ver prepareSelecoesEdicaoForNewSeason), nem o sorteio
    // nem a convocatória das OUTRAS nações são anunciados — a edição só "começa" de facto quando
    // confirmManualSelecaoSquad limpa esta flag e chama esta função de novo.
    if(state.pendingNationalSquadPick) return;
    pushSelecaoDrawNews(ed.prova, ed.groupA, ed.groupB, ed.hostCode, state.currentDate);
    pushSelecaoConvocationNews(ed.prova, ed.allCodes, state.currentDate);
    ed.announced = true;
  }

  // Resolução "em diferido" de uma edição que já ficou toda no passado — percorre os dias do
  // torneio (da véspera ao último dia) chamando o mesmo processamento diário, para as notícias
  // (antevisão, resultados, prémios) ficarem datadas dos dias reais de agosto. As equipas virtuais
  // são apagadas no fim, como sempre; a fadiga dos jogos não fica (ver resolveSelecaoMatch).
  function selecoesSub19CatchUp(ed){
    ed.catchUp = true;
    const first = addDays(ed.dates[0], -1);
    pushSelecaoDrawNews(ed.prova, ed.groupA, ed.groupB, ed.hostCode, first);
    pushSelecaoConvocationNews(ed.prova, ed.allCodes, first);
    ed.announced = true;
    for(let d = first; d <= ed.dates[5] && !ed.finished; d = addDays(d, 1)) processSelecaoEdicao(ed, d);
  }

  // Processamento diário — chamado a partir de processPhaseFiveFinalsForCurrentDate()
  // (07-playoff.js), tal como a Elite Cup/Europa/Taça de Portugal: só resolve e publica a notícia
  // de cada jornada/eliminatória quando state.currentDate já chegou à sua data fixa (ed.dates[i]),
  // nunca antes — é isto que faz as notícias dos jogos chegarem dia a dia, em vez de todas de
  // uma vez no dia da convocatória.
  //
  // Correção (2026-09-27, pedido do utilizador: "a antevisão está a vir depois dos resultados") —
  // antes, a antevisão e os resultados de cada jornada/eliminatória eram publicados na MESMA
  // data (ambos com state.currentDate no momento da resolução), ao contrário de toda a resta do
  // jogo (buildJornadaPreviewNews/buildJornadaResultsNews da liga do utilizador publicam a
  // antevisão um dia antes do jogo, os resultados só no próprio dia — precisamente o padrão que
  // o utilizador tinha pedido para as Seleções espelharem, "exatamente como uma jornada da liga
  // do utilizador"). Agora cada antevisão publica-se assim que possível, um dia antes da sua
  // resolução (ed.dates[i]-1) — o que cai sempre no dia em que a fase anterior se resolveu, já
  // que ed.dates tem sempre 1 dia de intervalo entre fases — e só a simulação/resultados espera
  // pela data fixa em si. ed.previewedGroupRounds/ed.qfPreviewed/ed.sfPreviewed/ed.finalPreviewed
  // e os pares pendentes (ed.qfPairs/ed.sfPairs/ed.thirdPairs/ed.finalPairs) são campos aditivos
  // simples (booleans/arrays de códigos) — sobrevivem a save/load tal e qual via
  // selecaoSerializeEdicao (spread de ed), sem precisar de tratamento especial.
  function processSelecoesForCurrentDate(){
    const sel = state.selecoes;
    if(!sel) return;
    if(sel.edicaoS19) processSelecaoEdicao(sel.edicaoS19, state.currentDate);
    if(sel.edicao) processSelecaoEdicao(sel.edicao, state.currentDate);
  }
  // Processa UMA edição (sénior ou Sub-19) para o dia `cur`.
  function processSelecaoEdicao(ed, cur){
    if(!ed || !ed.announced || ed.finished) return;

    if(!ed.previewedGroupRounds) ed.previewedGroupRounds = [false,false,false];

    // Correção (2026-09-27, apontada pelo utilizador: "os emails novos têm de aparecer em cima.
    // estao a aparecer por baixo ou no meio") — antes, o ciclo que antecipa a antevisão da
    // próxima jornada (um dia antes, ver comentário acima) corria ANTES de publicar os
    // resultados da jornada de hoje, mais abaixo. Como cada jornada de grupo tem só 1 dia de
    // intervalo da seguinte, isto acontecia TODOS os dias da fase de grupos (a antevisão da
    // jornada N+1 cai sempre no mesmo dia dos resultados da jornada N) — e como ambas ficam
    // com a mesma data, a que é publicada PRIMEIRO fica por cima na caixa de entrada. A
    // antevisão da jornada seguinte acabava assim a aparecer acima dos resultados de hoje,
    // que é exatamente o "a aparecer por baixo ou no meio" que o utilizador reportou (o e-mail
    // mais novo, os resultados de hoje, não ficava no topo). Resolvido publicando sempre
    // primeiro os resultados de hoje (ciclo "while" abaixo) e só depois anunciando a antevisão
    // do que vem a seguir.
    while(ed.roundsPlayed < 3 && cur >= ed.dates[ed.roundsPlayed]){
      const round = ed.roundsPlayed;
      const rA = ed.fixturesA[round], rB = ed.fixturesB[round];
      // Rede de segurança: garante a antevisão desta própria jornada mesmo que o dia de véspera
      // tenha sido saltado (ex.: vários dias avançados de uma vez durante o mercado).
      if(!ed.previewedGroupRounds[round]){
        pushSelecaoGroupNews(ed.prova, round, ed.groupA, ed.groupB, rA, rB, cur, false);
        ed.previewedGroupRounds[round] = true;
      }
      rA.concat(rB).forEach(fx=>{
        const r = resolveSelecaoMatch(fx.home, fx.away, ed.hostCode, false, ed.competitionId);
        fx.played=true; fx.homeScore=r.homeScore; fx.awayScore=r.awayScore; fx.soWinner=r.soWinner;
        applyStandings(selecaoVirtualTeamId(fx.home), selecaoVirtualTeamId(fx.away), r.homeScore, r.awayScore, r.soWinner);
      });
      pushSelecaoGroupNews(ed.prova, round, ed.groupA, ed.groupB, rA, rB, cur, true);
      ed.roundsPlayed++;
    }

    // Só agora — depois de publicados os resultados de hoje, se algum houve — anuncia-se a
    // antevisão da próxima jornada de grupo, um dia antes da sua resolução.
    for(let round=0; round<3; round++){
      if(!ed.previewedGroupRounds[round] && cur >= addDays(ed.dates[round], -1)){
        pushSelecaoGroupNews(ed.prova, round, ed.groupA, ed.groupB, ed.fixturesA[round], ed.fixturesB[round], cur, false);
        ed.previewedGroupRounds[round] = true;
      }
    }
    if(ed.roundsPlayed < 3) return;

    if(!ed.qfFixtures && !ed.qfPreviewed){
      const sortedA = sortSelecaoGroupCodes(ed.groupA), sortedB = sortSelecaoGroupCodes(ed.groupB);
      const seedLabels = {};
      sortedA.forEach((code,i)=>{ seedLabels[code] = (i+1)+"ºA"; });
      sortedB.forEach((code,i)=>{ seedLabels[code] = (i+1)+"ºB"; });
      // Cruzamento clássico pedido pelo utilizador ("os melhores no A, piores no B, e passam
      // todos"): 1ºA-4ºB, 2ºA-3ºB, 1ºB-4ºA, 2ºB-3ºA.
      const qfPairs = [
        [sortedA[0], sortedB[3]], [sortedA[1], sortedB[2]],
        [sortedB[0], sortedA[3]], [sortedB[1], sortedA[2]],
      ];
      ed.sortedA = sortedA; ed.sortedB = sortedB; ed.seedLabels = seedLabels; ed.qfPairs = qfPairs;
      pushSelecaoBracketPreview(ed.prova, "quartos", qfPairs, cur, seedLabels);
      ed.qfPreviewed = true;
    }
    if(!ed.qfFixtures && cur >= ed.dates[3]){
      ed.qfFixtures = resolveSelecaoBracketResults(ed.prova, "quartos", ed.qfPairs, ed.hostCode, cur, ed.competitionId, ed.seedLabels);
    }
    if(!ed.qfFixtures) return;

    if(!ed.sfFixtures && !ed.sfPreviewed){
      const sfPairs = [
        [ed.qfFixtures[0].winnerCode, ed.qfFixtures[1].winnerCode],
        [ed.qfFixtures[2].winnerCode, ed.qfFixtures[3].winnerCode],
      ];
      ed.sfPairs = sfPairs;
      pushSelecaoBracketPreview(ed.prova, "meias", sfPairs, cur);
      ed.sfPreviewed = true;
    }
    if(!ed.sfFixtures && cur >= ed.dates[4]){
      ed.sfFixtures = resolveSelecaoBracketResults(ed.prova, "meias", ed.sfPairs, ed.hostCode, cur, ed.competitionId);
    }
    if(!ed.sfFixtures) return;

    if(!ed.finalFixtures && !ed.finalPreviewed){
      const thirdPairs = [[ed.sfFixtures[0].loserCode, ed.sfFixtures[1].loserCode]];
      const finalPairs = [[ed.sfFixtures[0].winnerCode, ed.sfFixtures[1].winnerCode]];
      ed.thirdPairs = thirdPairs; ed.finalPairs = finalPairs;
      pushSelecaoBracketPreview(ed.prova, "terceiro", thirdPairs, cur);
      pushSelecaoBracketPreview(ed.prova, "final", finalPairs, cur);
      ed.finalPreviewed = true;
    }
    if(!ed.finalFixtures && cur >= ed.dates[5]){
      ed.thirdFixtures = resolveSelecaoBracketResults(ed.prova, "terceiro", ed.thirdPairs, ed.hostCode, cur, ed.competitionId);
      ed.finalFixtures = resolveSelecaoBracketResults(ed.prova, "final", ed.finalPairs, ed.hostCode, cur, ed.competitionId);

      const championCode = ed.finalFixtures[0].winnerCode, runnerUpCode = ed.finalFixtures[0].loserCode;
      const thirdCode = ed.thirdFixtures[0].winnerCode, fourthCode = ed.thirdFixtures[0].loserCode;
      const qfLosers = ed.qfFixtures.map(f=>f.loserCode).sort((a,b)=>{
        const sa = state.teams[selecaoVirtualTeamId(a)].stats, sb = state.teams[selecaoVirtualTeamId(b)].stats;
        if(sb.Pts!==sa.Pts) return sb.Pts-sa.Pts;
        return (sb.GM-sb.GS)-(sa.GM-sa.GS);
      });
      const finalRanking = [championCode, runnerUpCode, thirdCode, fourthCode].concat(qfLosers);

      pushSelecaoChampionNews(ed.prova, championCode, runnerUpCode, cur);

      // Registo do título na ficha do jogador (pedido explícito do utilizador, 2026-09-27: "os
      // jogadores que são campeões do mundo ou europa ficam com esse registo na folha") — todo
      // o plantel REAL da seleção campeã (nunca os jogadores fictícios __selecaoFiller, que não
      // têm ficha nenhuma) recebe o título, mesmo quem não chegou a jogar um único minuto — tal
      // como uma medalha real de equipa. Mesmo padrão de player.titulos já usado por
      // grantSeasonAward (08-evolucao-jogadores.js) e pelos títulos de clube (awardClubTitle) —
      // também conta para computePlayerReputation (titlesComponent, 06-motor-jogo.js), tal como
      // qualquer outro título.
      const championTituloTexto = (selecaoProvaBase(ed.prova)==="mundial" ? "Campeão do Mundo " : "Campeão da Europa ") + (selecaoProvaIsS19(ed.prova) ? "Sub-19 " : "") + seasonLabel(ed.season+1);
      state.teams[selecaoVirtualTeamId(championCode)].players.forEach(p=>{
        if(p.__selecaoFiller) return;
        if(!Array.isArray(p.titulos)) p.titulos=[];
        if(!p.titulos.includes(championTituloTexto)) p.titulos.push(championTituloTexto);
      });

      state.selecoesRanking = state.selecoesRanking || {};
      state.selecoesRanking[ed.prova] = finalRanking;

      // Selecção Nacional — Acumulação de Cargo (2026-10-03): se o utilizador for seleccionador de
      // alguma das nações desta edição, a federação avalia a campanha agora (ver
      // processSelecaoParticipationOutcome, 08c-staff-treinadores.js) — nunca afecta o clube.
      {
        const g = ensureManagerCareer();
        if(g.selecaoAtual && !ed.s19){
          const placementIndex = finalRanking.indexOf(g.selecaoAtual.code);
          if(placementIndex!==-1) processSelecaoParticipationOutcome(g.selecaoAtual.code, ed.season, ed.prova, placementIndex);
        }
      }

      // Estatísticas e prémios individuais da prova (pedido explícito do utilizador,
      // 2026-09-27: "também deve haver estatísticas e prêmios nos mundiais e europeus") —
      // reaproveita computeCompetitionAwards tal e qual (mesma seleção de Melhor Marcador/
      // Guarda-Redes/Jogador já usada nas competições de clube, 08-evolucao-jogadores.js), a
      // partir de ed.playerStats acumulado jogo a jogo em resolveSelecaoMatch.
      const selecaoAwardEntriesList = selecaoAwardEntries(ed);
      let marcadorAward=null, guardaRedesAward=null, jogadorAward=null, topScorersSnapshot=[];
      if(selecaoAwardEntriesList.length){
        const awards = computeCompetitionAwards(selecaoAwardEntriesList);
        marcadorAward = awards.marcador; guardaRedesAward = awards.guardaRedes; jogadorAward = awards.jogador;
        if(marcadorAward) grantSelecaoIndividualAward(marcadorAward, ed, "marcador", "Melhor Marcador");
        if(guardaRedesAward) grantSelecaoIndividualAward(guardaRedesAward, ed, "guardaRedes", "Melhor Guarda-Redes");
        if(jogadorAward) grantSelecaoIndividualAward(jogadorAward, ed, "jogador", "Melhor Jogador");
        pushSelecaoAwardsNews(ed, marcadorAward, guardaRedesAward, jogadorAward, cur);
        topScorersSnapshot = selecaoAwardEntriesList.slice()
          .sort((a,b)=>(b.golos-a.golos)||((b.golos/Math.max(1,b.jogos))-(a.golos/Math.max(1,a.jogos)))||a.player.name.localeCompare(b.player.name,"pt"))
          .slice(0,8)
          .map(e=>({ playerId:e.player.id, nome:e.player.name, teamId:e.team.id, golos:e.golos, jogos:e.jogos, assistencias:e.assistencias }));
      }

      // Interface (Fase 3): as equipas virtuais são apagadas logo a seguir — o histórico tem de
      // guardar TUDO o que a UI vai precisar de mostrar mais tarde (jornadas de grupo com
      // resultado, classificação final de cada grupo com estatísticas, e o quadro eliminatório
      // completo), nunca só o resumo (campeão/ranking). Snapshot simples (sem referências a
      // state.teams) — sobrevive tal e qual a save/load via compactSaveClone.
      const groupStandingsSnapshot = codes => codes.map(code=>{
        const st = state.teams[selecaoVirtualTeamId(code)].stats;
        return { code, J:st.J, V:st.V, E:st.E, D:st.D, GM:st.GM, GS:st.GS, Pts:st.Pts };
      });

      if(!Array.isArray(state.selecoesHistorico)) state.selecoesHistorico = [];
      state.selecoesHistorico.unshift({
        season: ed.season, prova: ed.prova, seasonLabel: seasonLabel(ed.season+1), hostCode: ed.hostCode,
        groupA: ed.groupA.slice(), groupB: ed.groupB.slice(),
        groupStandingsA: groupStandingsSnapshot(ed.sortedA), groupStandingsB: groupStandingsSnapshot(ed.sortedB),
        fixturesA: ed.fixturesA.map(round=>round.map(fx=>({home:fx.home,away:fx.away,homeScore:fx.homeScore,awayScore:fx.awayScore,soWinner:fx.soWinner,played:fx.played}))),
        fixturesB: ed.fixturesB.map(round=>round.map(fx=>({home:fx.home,away:fx.away,homeScore:fx.homeScore,awayScore:fx.awayScore,soWinner:fx.soWinner,played:fx.played}))),
        quartos: ed.qfFixtures.map(selecaoArchiveFixture), meias: ed.sfFixtures.map(selecaoArchiveFixture),
        terceiro: ed.thirdFixtures.map(selecaoArchiveFixture), final: ed.finalFixtures.map(selecaoArchiveFixture),
        campeao: championCode, finalista: runnerUpCode, terceiro_lugar: thirdCode, quarto: fourthCode,
        ranking: finalRanking.slice(),
        // Estatísticas e prémios individuais (snapshot simples, sem referências a state.teams —
        // sobrevive à eliminação das equipas virtuais e a um ciclo save/load).
        premiosIndividuais: {
          marcador: marcadorAward ? { playerId:marcadorAward.player.id, nome:marcadorAward.player.name, teamId:marcadorAward.team.id, golos:marcadorAward.golos } : null,
          guardaRedes: guardaRedesAward ? { playerId:guardaRedesAward.player.id, nome:guardaRedesAward.player.name, teamId:guardaRedesAward.team.id, golosSofridos:guardaRedesAward.golosSofridos, jogos:guardaRedesAward.jogos } : null,
          jogador: jogadorAward ? { playerId:jogadorAward.player.id, nome:jogadorAward.player.name, teamId:jogadorAward.team.id } : null,
        },
        topScorers: topScorersSnapshot,
      });
      if(state.selecoesHistorico.length>30) state.selecoesHistorico.length = 30;

      ed.allCodes.forEach(code=>{ delete state.teams[selecaoVirtualTeamId(code)]; });
      ed.finished = true;
      if(ed.s19) state.selecoes.edicaoS19 = null; else state.selecoes.edicao = null;
    }
  }

  // Serialização de state.selecoes.edicao para o save (11-guardar-carregar.js) — mesmo padrão de
  // europaSerializeEdicao/europaDeserializeEdicao (07g-europa.js). Correção necessária a partir de
  // 2026-09-27 (pedido do utilizador: "o jogo tem de começar com a noticia da convocatória...
  // depois vemos as noticias dos jogos"): antes desta correção, o torneio inteiro resolvia-se
  // sempre numa única chamada síncrona — nunca havia uma edição "em curso" para gravar. Agora que a
  // resolução se estende por vários dias reais (uma jornada/eliminatória de cada vez, ver
  // processSelecoesForCurrentDate acima), um save a meio do torneio TEM de preservar esta estrutura
  // — sem isto, uma edição em curso perdia-se ao carregar (as equipas virtuais ficavam órfãs em
  // state.teams para sempre, sem nada que as viesse a resolver ou a apagar). Só ed.dates tem
  // objetos Date — o resto (códigos, resultados, flags) já é JSON-safe tal e qual.
  function selecaoSerializeEdicao(ed){
    if(!ed) return null;
    return { ...ed, dates: ed.dates.map(d=>new Date(d).toISOString()) };
  }
  function selecaoDeserializeEdicao(ed){
    if(!ed) return null;
    return { ...ed, dates: ed.dates.map(d=>new Date(d)) };
  }
