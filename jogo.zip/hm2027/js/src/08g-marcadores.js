// Marcadores designados (2026-10-11, pedido do utilizador: ideia 2 da quarta lista de ideias).
// Decisões de desenho confirmadas por ele:
//  - só dois tipos de bola parada: LIVRES DIRETOS e PENÁLTIS EM JOGO;
//  - efeito "atributos reais + especialista": a probabilidade continua a sair dos atributos reais
//    do batedor (Bolas Paradas + Determinação, com fadiga), ajustada pela moral e pelo
//    historial de conversão do próprio jogador ao longo da carreira (taxa de golos / tentativas).
//    Quem está designado e está em pista cobra sempre; se não estiver em pista (banco, expulso,
//    lesionado), cobra quem o motor escolheria sem designação.
//
// Dados: team.marcadores = { livre: playerId|null, penalti: playerId|null } (guardado com a
// equipa; saves antigos criam-no de forma preguiçosa) e player.bolaParadaHist = { livreT, livreG,
// penT, penG } (carreira inteira, guardado com o jogador).

const MARCADORES_TIPOS = {
  livre:   { kind: "livredireto", label: "Livres diretos",   tentKey: "livresDiretosTentados", golKey: "livresDiretosMarcados", histT: "livreT", histG: "livreG", esperado: 0.30 },
  penalti: { kind: "penalti",     label: "Penáltis em jogo", tentKey: "penaltisTentados",      golKey: "penaltisMarcados",      histT: "penT",   histG: "penG",   esperado: 0.46 },
};
const MARCADORES_BONUS_DESIGNADO = 1.5;   // confiança de quem sabe que é o batedor (em pontos de skill)
const MARCADORES_MORAL_MAX = 1.5;         // ±1,5 em skill conforme a moral
const MARCADORES_HIST_MAX = 2.0;          // ±2,0 em skill conforme a taxa de conversão
const MARCADORES_HIST_AMOSTRA = 12;       // tentativas para o historial pesar por inteiro

function tipoMarcadorDoKind(kind){
  return kind === "penalti" ? "penalti" : "livre";
}
function ensureMarcadores(team){
  if(!team) return { livre: null, penalti: null };
  if(!team.marcadores || typeof team.marcadores !== "object") team.marcadores = { livre: null, penalti: null };
  if(team.marcadores.livre === undefined) team.marcadores.livre = null;
  if(team.marcadores.penalti === undefined) team.marcadores.penalti = null;
  return team.marcadores;
}
function marcadorHist(p){
  if(!p.bolaParadaHist || typeof p.bolaParadaHist !== "object") p.bolaParadaHist = { livreT: 0, livreG: 0, penT: 0, penG: 0 };
  return p.bolaParadaHist;
}
function marcadorRegistar(p, tipo, marcou){
  if(!p) return;
  const t = MARCADORES_TIPOS[tipo], h = marcadorHist(p);
  h[t.histT] = (h[t.histT] || 0) + 1;
  if(marcou) h[t.histG] = (h[t.histG] || 0) + 1;
}
// Conversão de carreira: usa o historial guardado; um save antigo não tem historial, por isso
// aproveita também os contadores da época corrente (que já existiam) quando maiores.
function marcadorConversao(p, tipo){
  const t = MARCADORES_TIPOS[tipo], h = marcadorHist(p);
  const s = p.season || {};
  const T = Math.max(h[t.histT] || 0, s[t.tentKey] || 0);
  const G = Math.max(h[t.histG] || 0, s[t.golKey] || 0);
  return { tentativas: T, golos: Math.min(G, T), taxa: T > 0 ? Math.min(G, T) / T : null };
}
function marcadorAjusteEspecialista(p, tipo){
  const c = marcadorConversao(p, tipo);
  if(c.taxa == null) return 0;
  const peso = clamp(c.tentativas / MARCADORES_HIST_AMOSTRA, 0, 1);
  return clamp((c.taxa - MARCADORES_TIPOS[tipo].esperado) * 5, -MARCADORES_HIST_MAX, MARCADORES_HIST_MAX) * peso;
}
function marcadorAjusteMoral(p){
  const m = p && p.moral != null ? p.moral : 60;
  return clamp((m - 60) / 40 * MARCADORES_MORAL_MAX, -MARCADORES_MORAL_MAX, MARCADORES_MORAL_MAX);
}
// Ajuste total à skill do batedor para uma bola parada. Aplica-se a TODOS os batedores (do
// utilizador e da IA); só o bónus de designado depende de a equipa ter escolhido o jogador.
function marcadorAjusteSkill(p, kind, designado){
  if(!p) return 0;
  const tipo = tipoMarcadorDoKind(kind);
  return marcadorAjusteEspecialista(p, tipo) + marcadorAjusteMoral(p) + (designado ? MARCADORES_BONUS_DESIGNADO : 0);
}
// O designado só cobra se estiver em pista (jogador de campo da escalação ao vivo).
function marcadorDesignadoEmPista(team, kind, lineup){
  if(!team || !lineup || !Array.isArray(lineup.outfield)) return null;
  const id = ensureMarcadores(team)[tipoMarcadorDoKind(kind)];
  if(!id) return null;
  return lineup.outfield.find(p => p.id === id) || null;
}

// Valor do batedor para sugestões do adjunto (atributos reais + estado + historial).
function marcadorScore(p, tipo){
  const base = p.attrs.bolasParadas * 0.75 + p.attrs.determinacao * 0.25;
  return base + marcadorAjusteEspecialista(p, tipo) + marcadorAjusteMoral(p);
}
function marcadoresCandidatos(team, tipo){
  return (team.players || [])
    .filter(p => p.pos !== "GR" && playerAvailableForMatch(p))
    .map(p => ({ p, score: marcadorScore(p, tipo), conv: marcadorConversao(p, tipo) }))
    .sort((a, b) => b.score - a.score);
}
function marcadorSugestaoAdjunto(team, tipo){
  const lista = marcadoresCandidatos(team, tipo);
  return lista.length ? lista[0] : null;
}
function setMarcador(tipo, playerId){
  const team = myTeam();
  if(!team || !MARCADORES_TIPOS[tipo]) return false;
  const m = ensureMarcadores(team);
  if(!playerId){ m[tipo] = null; return true; }
  const p = (team.players || []).find(x => x.id === playerId);
  if(!p || p.pos === "GR") return false;
  m[tipo] = playerId;
  return true;
}
function marcadorValido(team, tipo){
  const id = ensureMarcadores(team)[tipo];
  if(!id) return null;
  const p = (team.players || []).find(x => x.id === id);
  if(!p){ team.marcadores[tipo] = null; return null; }
  return p;
}

function renderMarcadoresHtml(team){
  const blocos = Object.keys(MARCADORES_TIPOS).map(tipo => {
    const t = MARCADORES_TIPOS[tipo];
    const atual = marcadorValido(team, tipo);
    const lista = marcadoresCandidatos(team, tipo).slice(0, 12);
    const sug = lista[0];
    const opcoes = ['<option value="">Automático (o motor escolhe em pista)</option>'].concat(lista.map(({ p, conv }) => {
      const hist = conv.tentativas ? ` · ${conv.golos}/${conv.tentativas}` : "";
      return `<option value="${escapeHtml(p.id)}"${atual && atual.id === p.id ? " selected" : ""}>${escapeHtml(p.name)} — Bolas Paradas ${p.attrs.bolasParadas}, Determ. ${p.attrs.determinacao}${hist}</option>`;
    })).join("");
    // O designado atual pode estar indisponível (lesão/suspensão): mostra-o na mesma, com aviso.
    const atualFora = atual && !lista.some(x => x.p.id === atual.id)
      ? `<option value="${escapeHtml(atual.id)}" selected>${escapeHtml(atual.name)} (indisponível)</option>` : "";
    const convAtual = atual ? marcadorConversao(atual, tipo) : null;
    const nota = atual
      ? `<div class="helptext" style="margin-top:4px;">${escapeHtml(atual.name)}: ${convAtual.tentativas ? `${convAtual.golos} golos em ${convAtual.tentativas} tentativas na carreira (${Math.round(convAtual.taxa * 100)}%)` : "ainda sem tentativas registadas"}. Se não estiver em pista, cobra quem o motor escolher.</div>`
      : `<div class="helptext" style="margin-top:4px;">Sem designado, cobra um jogador em pista escolhido pelo motor (favorece Bolas Paradas e Habilidade).</div>`;
    const sugestao = sug
      ? `<div class="helptext" style="margin-top:4px;">Sugestão do adjunto: <b>${escapeHtml(sug.p.name)}</b> (Bolas Paradas ${sug.p.attrs.bolasParadas}, Determinação ${sug.p.attrs.determinacao}${sug.conv.tentativas ? `, ${sug.conv.golos}/${sug.conv.tentativas} na carreira` : ""}).</div>` : "";
    return `<div style="margin-bottom:12px;">
      <label style="font-size:12px;display:block;font-weight:600;">${t.label}</label>
      <select class="marcador-select" data-marcador="${tipo}" style="width:100%;max-width:520px;">${atualFora}${opcoes}</select>
      ${nota}${sugestao}
    </div>`;
  }).join("");
  return `<div class="eyebrow" style="margin:20px 0 8px;">Marcadores designados</div>
    <p class="helptext" style="margin-bottom:10px;">Escolhe quem bate os livres diretos e os penáltis em jogo. A probabilidade de golo vem dos atributos reais do batedor, ajustada pela moral e pelo historial de conversão de carreira; o designado em pista ganha ainda a confiança de quem sabe que é o batedor.</p>
    ${blocos}`;
}

document.body.addEventListener("change", (e) => {
  const sel = e.target.closest && e.target.closest(".marcador-select");
  if(!sel) return;
  setMarcador(sel.getAttribute("data-marcador"), sel.value || null);
  if(typeof renderTaticasView === "function") renderTaticasView();
});
