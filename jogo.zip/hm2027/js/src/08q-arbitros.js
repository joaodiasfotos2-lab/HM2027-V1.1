// Árbitros com perfil (2026-10-12, pedido do utilizador: ideia 5 da nona lista).
// Decisões de desenho confirmadas por ele:
//  - cada país e escalão tem uma POOL de árbitros com perfil (caseiro, rigoroso, permissivo,
//    consistente); a Federação nomeia um por jogo e o adjunto avisa antes do jogo;
//  - efeitos: cartões e faltas, viés caseiro (mais forte em jogos grandes e pavilhões cheios),
//    erros e polémicas, e humor dos adeptos / balneário depois de uma má arbitragem;
//  - o utilizador pode fazer uma reclamação à Federação, declarações públicas e pedir o
//    afastamento de um árbitro; a Federação decide o que acontece;
//  - todos os jogos de todas as ligas têm árbitro e usam os efeitos; a IA também reclama; o
//    adjunto avisa do perfil e cada árbitro guarda o seu histórico (página na Direção).
//
// O RGHP trata de nomeações e da disciplina em termos gerais mas não fixa perfis, taxas de erro,
// nem como a Federação pesa uma queixa: todos os valores numéricos são ESTIMATIVAS (rigoroso ×1,3
// cartões, permissivo ×0,75, caseiro ±12% nos cartões e +20% de penáltis a favor da casa, taxa de
// erro por qualidade, probabilidades de decisão da Federação, multas, limites de afastamento).
//
// Dados globais em state.arbitros (guardado com o jogo):
//   pool        { "<pais>|<escalão>": [ árbitro ] }
//   nomeacoes   { "<casaId>|<foraId>": { refId, data } }  nomeações anunciadas (relatório do adjunto)
//   pendentes   polémicas contra o clube do utilizador à espera de reação
//   relacao     { teamId: 0–100 }  relação de cada clube com a Federação (50 = normal)
//   afast       { teamId: { epoca, ids[] } }  árbitros afastados a pedido do clube
// Árbitro: { id, nome, pais, rank, perfil, qual, jogos, cartoes, faltas, penaltis, polemicas,
//   erros, advertencias, indisponivelAte }

const ARB_PERFIS = {
  caseiro: { label: "Caseiro", texto: "Tende a favorecer quem joga em casa: menos cartões à casa, mais penáltis a favor da casa. Pior para quem visita, sobretudo em jogos grandes e pavilhões cheios." },
  rigoroso: { label: "Rigoroso", texto: "Mostra muitos cartões e assinala muitas faltas e penáltis. Pune a agressividade e o jogo duro." },
  permissivo: { label: "Permissivo", texto: "Deixa jogar: menos cartões, menos faltas e menos penáltis. Favorece o jogo físico." },
  consistente: { label: "Consistente", texto: "Critério uniforme para as duas equipas e menos erros do que a média." },
};
// escalão = teamDivisionRank: 3 = divisões de topo (com playoff), 2 = 2.ª divisão, 1 = 3.ª divisão
const ARB_POOL_TAMANHO = { 3: 10, 2: 10, 1: 14 };
const ARB_MEDIA_CARTOES = 6.7, ARB_MEDIA_FALTAS = 18.2, ARB_MEDIA_PENALTIS = 0.2;
const ARB_PENDENTE_DIAS = 14;
const ARB_AFASTAMENTO_RELACAO_MIN = 35;

function arbitroEnsure(){
  if(!state.arbitros || typeof state.arbitros !== "object") state.arbitros = { v: 1, pool: {}, nomeacoes: {}, pendentes: [], relacao: {}, afast: {}, seq: 0, ultimoMes: null };
  const a = state.arbitros;
  if(!a.pool) a.pool = {};
  if(!a.nomeacoes) a.nomeacoes = {};
  if(!Array.isArray(a.pendentes)) a.pendentes = [];
  if(!a.relacao) a.relacao = {};
  if(!a.afast) a.afast = {};
  if(a.seq == null) a.seq = 0;
  return a;
}
function arbitroIso(extraDias){
  const d = new Date(state.currentDate || new Date());
  if(extraDias) d.setDate(d.getDate() + extraDias);
  return d.toISOString().slice(0, 10);
}
function arbitroPais(team){ return typeof viagemPais === "function" ? (viagemPais(team) || "pt") : "pt"; }
function arbitroGauss(){
  const u1 = Math.max(1e-9, Math.random()), u2 = Math.random();
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
}
function arbitroNovo(pais, rank){
  const a = arbitroEnsure();
  const perfis = Object.keys(ARB_PERFIS);
  const perfil = perfis[Math.floor(Math.random() * perfis.length)];
  const qual = Math.round(clamp(66 + arbitroGauss() * 10 + (perfil === "consistente" ? 6 : 0), 40, 92));
  // Histórico inicial plausível para o perfil: assim o perfil já se reconhece nas estatísticas.
  const jogos = 8 + Math.floor(Math.random() * 18);
  const cm = perfil === "rigoroso" ? 1.3 : perfil === "permissivo" ? 0.75 : 1;
  const fm = perfil === "rigoroso" ? 1.12 : perfil === "permissivo" ? 0.9 : 1;
  const pm = perfil === "rigoroso" ? 1.1 : perfil === "permissivo" ? 0.9 : 1;
  a.seq++;
  return {
    id: `arb-${pais}-${rank}-${a.seq}`, nome: randomNameForCountry(pais), pais, rank, perfil, qual,
    jogos, cartoes: Math.round(jogos * ARB_MEDIA_CARTOES * cm * (0.9 + Math.random() * 0.2)),
    faltas: Math.round(jogos * ARB_MEDIA_FALTAS * fm * (0.92 + Math.random() * 0.16)),
    penaltis: Math.round(jogos * ARB_MEDIA_PENALTIS * pm * (0.6 + Math.random() * 0.8)),
    polemicas: Math.round(jogos * clamp(0.12 - (qual - 60) / 400, 0.01, 0.2) * (0.5 + Math.random())), erros: 0,
    advertencias: 0, indisponivelAte: null,
  };
}
function arbitroPool(pais, rank){
  const a = arbitroEnsure();
  const key = `${pais}|${rank}`;
  if(!a.pool[key]){
    const n = ARB_POOL_TAMANHO[rank] || 10;
    a.pool[key] = [];
    for(let i = 0; i < n; i++) a.pool[key].push(arbitroNovo(pais, rank));
  }
  return a.pool[key];
}
function arbitroPorId(id){
  const a = arbitroEnsure();
  for(const lista of Object.values(a.pool)){ const r = lista.find(x => x.id === id); if(r) return r; }
  return null;
}
function arbitroDisponivel(r){ return !r.indisponivelAte || arbitroIso() >= r.indisponivelAte; }
function arbitroAfastado(team, r){
  const a = arbitroEnsure(); const f = a.afast[team.id];
  return !!(f && f.epoca === state.season && f.ids.includes(r.id));
}
function arbitroRelacao(team){
  const a = arbitroEnsure();
  if(a.relacao[team.id] == null) a.relacao[team.id] = 50;
  return a.relacao[team.id];
}
function arbitroMudarRelacao(team, d){
  const a = arbitroEnsure();
  a.relacao[team.id] = clamp(arbitroRelacao(team) + d, 0, 100);
}
function arbitroRelacaoLabel(v){ return v >= 70 ? "Excelente" : v >= 55 ? "Boa" : v >= 40 ? "Normal" : v >= 25 ? "Tensa" : "Má"; }
function arbitroQualLabel(q){ return q >= 80 ? "Excelente" : q >= 68 ? "Boa" : q >= 55 ? "Média" : "Fraca"; }
function arbitroFedEmail(team){ return `arbitragem@${(typeof DISC_FEDERACAO !== "undefined" && DISC_FEDERACAO[arbitroPais(team)]) || "fpp.pt"}`; }

// Nomeação para um jogo (sem guardar): evita árbitros indisponíveis e os afastados pelos clubes.
function arbitroNomear(home, away, opts){
  const pais = arbitroPais(home);
  const rank = opts && opts.europa ? 3 : teamDivisionRank(home);
  const pool = arbitroPool(pais, rank).filter(arbitroDisponivel);
  let cand = pool.filter(r => !arbitroAfastado(home, r) && !arbitroAfastado(away, r));
  if(!cand.length) cand = pool.length ? pool : arbitroPool(pais, rank);
  return cand[Math.floor(Math.random() * cand.length)];
}
// Anúncio da nomeação (relatório pré-jogo do adjunto, chamado 1 dia antes). Guarda-a para o jogo.
function arbitroPrever(homeId, awayId, opts){
  const home = state.teams[homeId], away = state.teams[awayId];
  if(!home || !away) return null;
  const a = arbitroEnsure();
  const key = `${homeId}|${awayId}`;
  const existente = a.nomeacoes[key];
  if(existente && arbitroPorId(existente.refId)) return arbitroPorId(existente.refId);
  const r = arbitroNomear(home, away, opts);
  a.nomeacoes[key] = { refId: r.id, data: arbitroIso() };
  return r;
}
function arbitroDoJogo(home, away, opts){
  const a = arbitroEnsure();
  const key = `${home.id}|${away.id}`;
  const n = a.nomeacoes[key];
  if(n){
    delete a.nomeacoes[key];
    const r = arbitroPorId(n.refId);
    const idade = (new Date(state.currentDate) - new Date(n.data + "T00:00:00Z")) / 86400000;
    if(r && idade <= 10 && arbitroDisponivel(r)) return r;
  }
  return arbitroNomear(home, away, opts);
}
function arbitroLinhaAdjunto(homeId, awayId, euCasa){
  const r = arbitroPrever(homeId, awayId, {});
  if(!r) return "";
  const j = Math.max(1, r.jogos);
  const cj = r.cartoes / j;
  const pj = r.penaltis / j;
  let aviso = "";
  if(r.perfil === "caseiro") aviso = euCasa ? " Perfil caseiro: tende a jogar a nosso favor." : " Perfil caseiro: jogamos fora, convém evitar o jogo duro.";
  else if(r.perfil === "rigoroso") aviso = " Perfil rigoroso: mostra muitos cartões, convém baixar a agressividade.";
  else if(r.perfil === "permissivo") aviso = " Perfil permissivo: deixa jogar, o jogo físico é menos punido.";
  else aviso = " Perfil consistente: critério uniforme para as duas equipas.";
  return `Árbitro nomeado: <b>${escapeHtml(r.nome)}</b> (${ARB_PERFIS[r.perfil].label.toLowerCase()}) — ${cj.toFixed(1).replace(".", ",")} cartões e ${pj.toFixed(2).replace(".", ",")} penáltis por jogo (média do escalão: ${ARB_MEDIA_CARTOES.toFixed(1).replace(".", ",")} e ${ARB_MEDIA_PENALTIS.toFixed(2).replace(".", ",")}).${aviso}<br>`;
}

// ---------------------------------------------------------------------------------------------
// No jogo
// ---------------------------------------------------------------------------------------------
function arbitroArredonda(v){ const f = Math.floor(v); return f + (Math.random() < v - f ? 1 : 0); }
function arbitroAplicar(ctx){
  ctx.arbitro = null; ctx.arbErros = []; ctx.arbRate = null; ctx.arbPen = null; ctx.arbAnula = 1; ctx.arbErroBase = 0; ctx.arbVies = 0;
  if(ctx.isFriendly) return;
  const home = state.teams[ctx.homeId], away = state.teams[ctx.awayId];
  if(!home || !away) return;
  const ref = arbitroDoJogo(home, away, { europa: ctx.isEuropa, playoff: ctx.isPlayoff });
  if(!ref) return;
  ctx.arbitro = ref;
  const grande = !!ctx.isPlayoff || !!ctx.isEuropa || (typeof isDerby === "function" && isDerby(ctx.homeId, ctx.awayId));
  const cap = typeof pavilhaoCapacidade === "function" ? pavilhaoCapacidade(home) : (home.financeiro && home.financeiro.capacidadePavilhao) || 0;
  const cheio = cap > 0 && (ctx.attendance || 0) >= 0.9 * cap;
  const casa = ref.perfil === "caseiro" && !ctx.neutralVenue;
  const bias = 1 + (grande ? 0.25 : 0) + (cheio ? 0.35 : 0);
  ctx.arbVies = casa ? bias : 0;
  const cm = ref.perfil === "rigoroso" ? 1.3 : ref.perfil === "permissivo" ? 0.75 : 1;
  const fm = ref.perfil === "rigoroso" ? 1.12 : ref.perfil === "permissivo" ? 0.9 : 1;
  const pm = ref.perfil === "rigoroso" ? 1.1 : ref.perfil === "permissivo" ? 0.9 : 1;
  const bc = casa ? 0.12 * bias : 0;
  ctx.targetCards.home = Math.max(0, arbitroArredonda(ctx.targetCards.home * cm * (1 - bc)));
  ctx.targetCards.away = Math.max(0, arbitroArredonda(ctx.targetCards.away * cm * (1 + bc)));
  ctx.targetFaltas.home = Math.max(2, arbitroArredonda(ctx.targetFaltas.home * fm * (1 - bc * 0.5)));
  ctx.targetFaltas.away = Math.max(2, arbitroArredonda(ctx.targetFaltas.away * fm * (1 + bc * 0.5)));
  ctx.arbRate = { card: { home: cm * (1 - bc), away: cm * (1 + bc) }, foul: { home: fm * (1 - bc * 0.5), away: fm * (1 + bc * 0.5) } };
  ctx.arbPen = { home: pm * (casa ? 1 + 0.2 * bias : 1), away: pm * (casa ? 1 - 0.12 * bias : 1) };
  ctx.arbAnula = ref.perfil === "consistente" ? 0.8 : 1;
  ctx.arbErroBase = clamp(0.012 + (70 - ref.qual) / 2500, 0.003, 0.03) * (ref.perfil === "consistente" ? 0.5 : 1);
}
// Probabilidade de erro contra um lado (o árbitro caseiro erra mais contra o visitante).
function arbitroProbErro(ctx, ladoAfetado, mult){
  if(!ctx.arbitro) return 0;
  const v = ctx.arbVies || 0;
  const lado = v ? (ladoAfetado === "home" ? 1 / (1 + 0.4 * v) : 1 + 0.4 * v) : 1;
  return ctx.arbErroBase * mult * lado;
}
function arbitroRegistarErro(ctx, tipo, ladoAfetado, minuto, desc){
  if(!ctx.arbErros) ctx.arbErros = [];
  ctx.arbErros.push({ tipo, lado: ladoAfetado, minuto, desc });
}
// Golo anulado sem razão: devolve true (e regista) quando o árbitro erra contra o atacante.
function arbitroErroGolo(ctx, ladoAtacante){
  if(!ctx.arbitro || Math.random() >= arbitroProbErro(ctx, ladoAtacante, 0.5)) return false;
  arbitroRegistarErro(ctx, "golo", ladoAtacante, ctx.clock, "golo anulado por uma alegada falta anterior");
  return true;
}
// Penálti assinalado com muitas dúvidas contra o lado que faltou.
function arbitroTalvezPenaltiIndevido(ctx, ladoFaltoso, clock){
  if(!ctx.arbitro || Math.random() >= arbitroProbErro(ctx, ladoFaltoso, 8)) return;
  const nome = teamName(ctx, ladoFaltoso);
  addLog(ctx, clock, "sistema", `Decisão muito contestada: o penálti contra o ${nome} é duvidoso e os jogadores rodeiam o árbitro!`);
  arbitroRegistarErro(ctx, "penalti-indevido", ladoFaltoso, clock, "penálti duvidoso assinalado");
}
// Penálti por assinalar: os jogadores reclamam mas o jogo segue.
function arbitroTalvezPenaltiNaoMarcado(ctx, ladoBeneficiado, ladoFaltoso, clock){
  if(!ctx.arbitro || Math.random() >= arbitroProbErro(ctx, ladoBeneficiado, 0.5)) return;
  const nome = teamName(ctx, ladoBeneficiado);
  addLog(ctx, clock, "sistema", `O ${nome} reclama penálti por assinalar, mas o árbitro manda seguir — lance muito contestado!`);
  arbitroRegistarErro(ctx, "penalti-omitido", ladoBeneficiado, clock, "penálti por assinalar");
}

function arbitroAposJogo(ctx){
  const ref = ctx.arbitro;
  if(!ref || ctx.isFriendly) return;
  const a = arbitroEnsure();
  const home = state.teams[ctx.homeId], away = state.teams[ctx.awayId];
  if(!home || !away) return;
  const erros = ctx.arbErros || [];
  ref.jogos++;
  ref.cartoes += (ctx.cartoes.home || []).length + (ctx.cartoes.away || []).length;
  ref.faltas += (ctx.faltas.home || 0) + (ctx.faltas.away || 0);
  ref.penaltis += ((ctx.penaltiesAwarded || {}).home || 0) + ((ctx.penaltiesAwarded || {}).away || 0);
  if(erros.length){ ref.polemicas++; ref.erros += erros.length; }
  if(!erros.length) return;
  const grande = !!ctx.isPlayoff || !!ctx.isEuropa || (typeof isDerby === "function" && isDerby(ctx.homeId, ctx.awayId));
  const jogoTxt = `${home.name} ${ctx.score.home}-${ctx.score.away} ${away.name}`;
  // 2026-10-12 (pedido do utilizador): as reclamações formais são raras — só partem do clube que PERDEU e
  // só em jogos muito disputados (derrota por um golo; nos penáltis conta o vencedor da decisão).
  const dif = ctx.score.home - ctx.score.away;
  const perdedor = dif !== 0 ? (dif < 0 ? "home" : "away") : (ctx.soWinner ? (ctx.soWinner === "home" ? "away" : "home") : null);
  const disputado = Math.abs(dif) <= 1;
  ["home", "away"].forEach(lado => {
    const afetados = erros.filter(e => e.lado === lado);
    if(!afetados.length) return;
    const team = lado === "home" ? home : away;
    if(!team || team.nuvemEuropeia || team.selecaoNacional) return;
    // Humor dos adeptos e balneário ressentem-se de uma má arbitragem.
    if(typeof ensureAdeptos === "function"){ const ad = ensureAdeptos(team); if(ad) ad.humor = clamp(ad.humor - (grande ? 1.4 : 0.9) * Math.min(2, afetados.length), 0, 100); }
    if(typeof ensureBalneario === "function"){ const b = ensureBalneario(team); if(b) b.coesao = clamp(b.coesao - 1, 3, 99); }
    const descs = afetados.map(e => e.desc);
    // "Grave" = escandalosa: só estas podem acabar com uma advertência pública ao árbitro.
    const grave = afetados.length >= 3 || (afetados.length >= 2 && afetados.some(e => e.tipo === "golo" || e.tipo === "penalti-indevido"));
    const reclamavel = lado === perdedor && disputado;
    if(!reclamavel) return;
    if(isUserControlledTeam(team)){
      a.seq++;
      a.pendentes.push({ id: `pol-${a.seq}`, teamId: team.id, refId: ref.id, refNome: ref.nome, jogo: jogoTxt, data: arbitroIso(), expira: arbitroIso(ARB_PENDENTE_DIAS), descs, grave, reclamada: false, declarada: false });
      pushNews(state.currentDate,
        `<b>Arbitragem muito contestada no ${escapeHtml(jogoTxt)}.</b><br>O árbitro <b>${escapeHtml(ref.nome)}</b> (${ARB_PERFIS[ref.perfil].label.toLowerCase()}) tomou decisões que prejudicaram o ${teamLinkHtml(team.id)}: ${descs.map(escapeHtml).join("; ")}. Os adeptos estão revoltados e o balneário ressentiu-se.<br><br>Podes apresentar uma reclamação à Federação ou fazer declarações públicas, na Direção, na secção Arbitragem. Tens ${ARB_PENDENTE_DIAS} dias.`,
        "arbitragem", `Arbitragem polémica: ${jogoTxt}`, { sender: arbitroFedEmail(team), teamId: team.id });
    } else if(Math.random() < 0.3){
      // A IA também reclama (de vez em quando) e a Federação decide.
      const dec = arbitroDecidir(team, ref, grave);
      arbitroAplicarDecisao(team, ref, dec, false);
      if(newsIsFromUserDivision(team.name)){
        const frase = dec === "razao" ? `A Federação deu razão ao ${teamLinkHtml(team.id)} e advertiu o árbitro ${escapeHtml(ref.nome)}.`
          : dec === "infundada" ? `A Federação considerou infundada a queixa do ${teamLinkHtml(team.id)} e aplicou-lhe uma multa.`
          : `A Federação arquivou a queixa do ${teamLinkHtml(team.id)}.`;
        pushNews(state.currentDate, `Após o ${escapeHtml(jogoTxt)}, o ${teamLinkHtml(team.id)} apresentou uma reclamação formal contra a arbitragem. ${frase}`, "arbitragem", `Reclamação do ${team.name}`, { sender: arbitroFedEmail(team), teamId: team.id });
      }
    }
  });
}

// ---------------------------------------------------------------------------------------------
// Reações do clube: reclamação, declarações públicas e afastamento
// ---------------------------------------------------------------------------------------------
function arbitroDecidir(team, ref, grave){
  const rel = arbitroRelacao(team);
  const recentes = arbitroEnsure().pendentes.filter(p => p.teamId === team.id && p.reclamada).length;
  // A Federação só adverte publicamente um árbitro em casos escandalosos; numa queixa comum, quando muito arquiva.
  const pRazao = grave ? clamp(0.12 + (ref.qual < 58 ? 0.08 : 0) + (ref.polemicas >= 3 ? 0.05 : 0) + (rel - 50) / 400, 0.05, 0.35) : 0.01;
  const pInf = clamp(0.10 + (rel < 35 ? 0.12 : 0) + (recentes >= 3 ? 0.12 : 0), 0.05, 0.4);
  const r = Math.random();
  return r < pRazao ? "razao" : r < pRazao + pInf ? "infundada" : "arquivada";
}
function arbitroMulta(team, fator, descricao){
  const smn = typeof disciplinaSMN === "function" ? disciplinaSMN(team) : 1000;
  const valor = Math.round(smn * fator);
  addFinanceMovement(team, "despesa", "Multa disciplinar", descricao, valor, state.currentDate);
  return valor;
}
function arbitroAplicarDecisao(team, ref, dec, utilizador){
  let multa = 0, suspenso = false;
  if(dec === "razao"){
    ref.qual = Math.max(35, ref.qual - 3);
    ref.advertencias = (ref.advertencias || 0) + 1;
    if(ref.advertencias % 2 === 0){ ref.indisponivelAte = arbitroIso(28); suspenso = true; }
    arbitroMudarRelacao(team, 4);
    if(typeof ensureAdeptos === "function"){ const ad = ensureAdeptos(team); if(ad) ad.humor = clamp(ad.humor + 1, 0, 100); }
  } else if(dec === "infundada"){
    multa = arbitroMulta(team, 0.5, "Multa por reclamação infundada contra a arbitragem");
    arbitroMudarRelacao(team, -8);
  } else arbitroMudarRelacao(team, -1);
  return { multa, suspenso };
}
function arbitroReclamar(pendenteId){
  const a = arbitroEnsure();
  const p = a.pendentes.find(x => x.id === pendenteId);
  const team = myTeam();
  if(!p || !team || p.teamId !== team.id) return { ok: false, reason: "Polémica não encontrada." };
  if(p.reclamada) return { ok: false, reason: "Já apresentaste uma reclamação sobre este jogo." };
  const ref = arbitroPorId(p.refId);
  if(!ref) return { ok: false, reason: "Árbitro não encontrado." };
  p.reclamada = true;
  const dec = arbitroDecidir(team, ref, p.grave);
  const r = arbitroAplicarDecisao(team, ref, dec, true);
  const frase = dec === "razao"
    ? `A Federação deu razão ao ${escapeHtml(team.name)}: o árbitro ${escapeHtml(ref.nome)} foi advertido${r.suspenso ? " e fica suspenso de nomeações durante 4 semanas" : ""}. Os adeptos sentem-se compensados e a relação com a Federação melhora.`
    : dec === "infundada" ? `A Federação considerou a queixa infundada e aplicou ao clube uma multa de ${fmtMoney(r.multa)}. A relação com a Federação piorou.`
    : "A Federação arquivou a queixa sem consequências. A relação com a Federação ressente-se ligeiramente.";
  pushNews(state.currentDate, `<b>Reclamação à Federação</b> sobre ${escapeHtml(p.jogo)} (árbitro ${escapeHtml(p.refNome)}).<br>${frase}`, "arbitragem", `Reclamação: ${p.jogo}`, { sender: arbitroFedEmail(team), teamId: team.id });
  return { ok: true, dec, multa: r.multa };
}
function arbitroDeclarar(pendenteId){
  const a = arbitroEnsure();
  const p = a.pendentes.find(x => x.id === pendenteId);
  const team = myTeam();
  if(!p || !team || p.teamId !== team.id) return { ok: false, reason: "Polémica não encontrada." };
  if(p.declarada) return { ok: false, reason: "Já fizeste declarações sobre este jogo." };
  p.declarada = true;
  if(typeof ensureAdeptos === "function"){ const ad = ensureAdeptos(team); if(ad) ad.humor = clamp(ad.humor + 1.5, 0, 100); }
  if(typeof ensureBalneario === "function"){ const b = ensureBalneario(team); if(b) b.coesao = clamp(b.coesao + 0.5, 3, 99); }
  arbitroMudarRelacao(team, -3);
  let extra = "";
  if(Math.random() < 0.4){
    const valor = arbitroMulta(team, 1 + Math.floor(Math.random() * 3), "Multa por declarações públicas contra a arbitragem");
    extra = ` A Federação abriu um processo por declarações públicas e aplicou ao clube uma multa de ${fmtMoney(valor)}.`;
  }
  pushNews(state.currentDate, `As declarações do treinador do ${teamLinkHtml(team.id)} contra a arbitragem do ${escapeHtml(p.jogo)} agradaram aos adeptos e uniram o grupo, mas a relação com a Federação sofreu.${extra}`, "arbitragem", "Declarações sobre a arbitragem", { sender: arbitroFedEmail(team), teamId: team.id });
  return { ok: true };
}
function arbitroPedirAfastamento(refId){
  const a = arbitroEnsure();
  const team = myTeam();
  const ref = arbitroPorId(refId);
  if(!team || !ref) return { ok: false, reason: "Árbitro não encontrado." };
  const f = a.afast[team.id] && a.afast[team.id].epoca === state.season ? a.afast[team.id] : (a.afast[team.id] = { epoca: state.season, ids: [] });
  if(f.ids.length >= 1) return { ok: false, reason: "Só podes pedir o afastamento de um árbitro por época." };
  if(arbitroRelacao(team) < ARB_AFASTAMENTO_RELACAO_MIN) return { ok: false, reason: "A relação com a Federação está demasiado má para apresentares este pedido." };
  if(ref.qual >= 80){
    arbitroMudarRelacao(team, -2);
    return { ok: false, reason: "A Federação recusou: não aceita afastar um árbitro de topo." };
  }
  f.ids.push(ref.id);
  arbitroMudarRelacao(team, -6);
  pushNews(state.currentDate, `A Federação aceitou o pedido do ${teamLinkHtml(team.id)}: o árbitro <b>${escapeHtml(ref.nome)}</b> não será nomeado para os jogos do clube até ao fim da época. O pedido deixou marcas na relação com a Federação.`, "arbitragem", `Afastamento: ${ref.nome}`, { sender: arbitroFedEmail(team), teamId: team.id });
  return { ok: true };
}

// ---------------------------------------------------------------------------------------------
// Ciclos: diário, mensal e fim de época
// ---------------------------------------------------------------------------------------------
function arbitroDiario(){
  const a = state.arbitros; if(!a) return;
  const hoje = arbitroIso();
  a.pendentes = a.pendentes.filter(p => p.expira >= hoje);
  const chaves = Object.keys(a.nomeacoes);
  chaves.forEach(k => { const n = a.nomeacoes[k]; if((new Date(hoje) - new Date(n.data)) / 86400000 > 12) delete a.nomeacoes[k]; });
}
function arbitroMensal(date){
  const a = arbitroEnsure();
  const d = new Date(date), mes = `${d.getFullYear()}-${d.getMonth() + 1}`;
  if(a.ultimoMes === mes) return;
  a.ultimoMes = mes;
  Object.keys(a.relacao).forEach(id => { const v = a.relacao[id]; a.relacao[id] = v > 50 ? Math.max(50, v - 1) : Math.min(50, v + 1); });
}
function arbitroFimDeEpoca(){
  const a = arbitroEnsure();
  Object.keys(a.pool).forEach(key => {
    const [pais, rank] = key.split("|");
    a.pool[key] = a.pool[key].map(r => {
      const taxa = r.jogos ? r.polemicas / r.jogos : 0;
      r.qual = Math.round(clamp(r.qual + arbitroGauss() * 2.5 - (taxa > 0.15 ? 2 : 0), 35, 95));
      r.advertencias = 0; r.indisponivelAte = null;
      if(r.jogos >= 15 && r.qual < 45) return arbitroNovo(pais, parseInt(rank, 10));   // sai da pool e entra um novo
      return r;
    });
  });
  a.afast = {};
  a.pendentes = [];
  a.nomeacoes = {};
}

// ---------------------------------------------------------------------------------------------
// Painel (Direção)
// ---------------------------------------------------------------------------------------------
function arbitroPainelProximo(team){
  const a = arbitroEnsure();
  const chave = Object.keys(a.nomeacoes).find(k => k.split("|").includes(team.id));
  if(!chave) return "";
  const n = a.nomeacoes[chave]; const r = arbitroPorId(n.refId); if(!r) return "";
  const [h, f] = chave.split("|");
  const ht = state.teams[h], ft = state.teams[f];
  if(!ht || !ft) return "";
  return `<p class="helptext">Próximo jogo (${escapeHtml(ht.name)} vs ${escapeHtml(ft.name)}): árbitro <b>${escapeHtml(r.nome)}</b>, perfil ${ARB_PERFIS[r.perfil].label.toLowerCase()}.</p>`;
}
function arbitroPanelHtml(team){
  if(!team || !isUserControlledTeam(team)) return "";
  const a = arbitroEnsure();
  const rel = arbitroRelacao(team);
  const pendentes = a.pendentes.filter(p => p.teamId === team.id);
  const pais = arbitroPais(team), rank = teamDivisionRank(team);
  const pool = arbitroPool(pais, rank);
  const f = a.afast[team.id] && a.afast[team.id].epoca === state.season ? a.afast[team.id] : null;
  const pend = pendentes.length ? pendentes.map(p => `<div style="border:1px solid var(--border,#ddd);border-radius:8px;padding:8px;margin:6px 0;">
      <div><b>${escapeHtml(p.jogo)}</b> · árbitro ${escapeHtml(p.refNome)} · até ${fmtDateShort(new Date(p.expira))}</div>
      <div class="helptext">${p.descs.map(escapeHtml).join("; ")}</div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px;">
        <button class="btn btn-ghost arb-reclamar" data-id="${p.id}" ${p.reclamada ? "disabled" : ""}>${p.reclamada ? "Reclamação enviada" : "Reclamar à Federação"}</button>
        <button class="btn btn-ghost arb-declarar" data-id="${p.id}" ${p.declarada ? "disabled" : ""}>${p.declarada ? "Declarações feitas" : "Declarações públicas"}</button>
      </div></div>`).join("") : `<p class="helptext">Sem polémicas por tratar.</p>`;
  const linhas = pool.slice().sort((x, y) => y.jogos - x.jogos).map(r => {
    const j = Math.max(1, r.jogos);
    const afast = f && f.ids.includes(r.id);
    const susp = r.indisponivelAte && arbitroIso() < r.indisponivelAte;
    return `<tr><td>${escapeHtml(r.nome)}${afast ? " <span class=\"helptext\">(afastado)</span>" : ""}${susp ? " <span class=\"helptext\">(suspenso)</span>" : ""}</td><td>${ARB_PERFIS[r.perfil].label}</td><td>${r.jogos}</td><td>${(r.cartoes / j).toFixed(1).replace(".", ",")}</td><td>${(r.faltas / j).toFixed(1).replace(".", ",")}</td><td>${(r.penaltis / j).toFixed(2).replace(".", ",")}</td><td>${r.polemicas}</td><td>${arbitroQualLabel(r.qual)}</td></tr>`;
  }).join("");
  const opcoesAfast = pool.filter(r => !(f && f.ids.includes(r.id))).map(r => `<option value="${r.id}">${escapeHtml(r.nome)} (${ARB_PERFIS[r.perfil].label.toLowerCase()})</option>`).join("");
  return `<div class="eyebrow" style="margin:16px 0 8px;">Arbitragem</div>
    <p class="helptext" style="margin-bottom:6px;">Relação com a Federação: <b>${arbitroRelacaoLabel(rel)}</b>. Reclamações bem fundamentadas melhoram-na; queixas infundadas e declarações públicas pioram-na.</p>
    ${arbitroPainelProximo(team)}
    ${pend}
    <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin:8px 0;">
      <select id="arbAfastarSel" ${f ? "disabled" : ""}>${opcoesAfast}</select>
      <button class="btn btn-ghost arb-afastar" ${f ? "disabled" : ""}>${f ? "Pedido já feito esta época" : "Pedir afastamento do árbitro"}</button>
    </div>
    <details><summary class="helptext" style="cursor:pointer;">Histórico dos árbitros do escalão (${pool.length})</summary>
      <div style="overflow-x:auto;"><table class="data-table" style="width:100%;font-size:12px;"><thead><tr><th>Árbitro</th><th>Perfil</th><th>Jogos</th><th>Cart./jogo</th><th>Faltas/jogo</th><th>Pen./jogo</th><th>Polémicas</th><th>Qualidade</th></tr></thead><tbody>${linhas}</tbody></table></div>
    </details>`;
}
document.addEventListener("click", (e) => {
  const t = e.target; if(!t || !t.closest) return;
  const redraw = () => { if(typeof renderDirectionPanel === "function") renderDirectionPanel(); };
  const rec = t.closest(".arb-reclamar");
  if(rec){ const r = arbitroReclamar(rec.getAttribute("data-id")); showTransientNotice(r.ok ? "Reclamação apresentada." : r.reason); redraw(); return; }
  const dec = t.closest(".arb-declarar");
  if(dec){ const r = arbitroDeclarar(dec.getAttribute("data-id")); showTransientNotice(r.ok ? "Declarações feitas." : r.reason); redraw(); return; }
  if(t.closest(".arb-afastar")){
    const sel = document.getElementById("arbAfastarSel"); if(!sel || !sel.value) return;
    const r = arbitroPedirAfastamento(sel.value); showTransientNotice(r.ok ? "Pedido aceite." : r.reason); redraw();
  }
});
