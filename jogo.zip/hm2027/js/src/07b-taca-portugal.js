  // ============================= 07b-taca-portugal.js =============================
  // Taça de Portugal (masculina) — eliminação direta a uma mão, aberta a todas as divisões
  // (Placard, 2ª e 3ª), com Pré-Eliminatória para chegar a um quadro de 64, sorteio especial
  // nos 32 Avos (clubes do Placard nunca se defrontam entre si nessa ronda), e sorteio
  // totalmente livre a partir dos 16 Avos. Fase final em Final Four, recinto neutro.
  //
  // Interpretação assumida (o regulamento não o diz explicitamente, mas a regra especial só
  // existe a partir dos 32 Avos — implica que os 14 clubes do Placard já lá estão garantidos):
  // os clubes do Placard nunca entram na Pré-Eliminatória, têm sempre bye direto para os 32
  // Avos. Só os clubes da 2ª/3ª Divisão competem pelas vagas de bye/Pré-Eliminatória.
  //
  // As equipas B (qualquer uma, incluindo as detetadas por nome na 3ª Divisão) estão excluídas
  // por regulamento (Artigo 43.º, ponto 9 do RGHP).

  const TACA_FASES = ["pre-eliminatoria","32avos","16avos","oitavos","quartos","meiafinal","final"];
  const TACA_FASE_LABEL = {
    "pre-eliminatoria":"Taça de Portugal — Pré-Eliminatória",
    "32avos":"Taça de Portugal — 32 Avos de Final",
    "16avos":"Taça de Portugal — 16 Avos de Final",
    "oitavos":"Taça de Portugal — Oitavos de Final",
    "quartos":"Taça de Portugal — Quartos de Final",
    "meiafinal":"Taça de Portugal — Meias-Finais (Final Four)",
    "final":"Taça de Portugal — Final (Final Four)",
  };

  // Correção: usar isMarketPassiveTeam() aqui (que também deteta "equipas B" pelo nome, para
  // efeitos de mercado) excluía incorretamente clubes cujo nome real termina em "B" mas que
  // nunca tiveram uma equipa principal formalmente ligada no jogo — são clubes independentes,
  // promovíveis como qualquer outro (e confirmei, já chegaram ao Placard legitimamente). O
  // Artigo 43.º do RGHP só exclui da Taça as equipas B formalmente subordinadas a um clube
  // principal — por isso aqui usa-se especificamente essa ligação (equipaPrincipalId), não a
  // deteção por nome.
  // Encontra a eliminatória da Taça do clube do utilizador na fase atual, ainda por jogar (para
  // a antevisão/relatório pré-jogo, chamados 1 dia antes — ver continuarBtn em 09-fluxo-epoca.js).
  function tacaMyTieForCurrentDate(){
    const tp = state.tacaPortugal;
    if(!tp || tp.fase==="concluida") return null;
    const jogos = tp.jogos[tp.fase]||[];
    return jogos.find(j=>!j.played && (j.home===state.userTeamId || j.away===state.userTeamId)) || null;
  }
  function tacaBuildPreviewNews(tie){
    const tp = state.tacaPortugal;
    const oppId = tie.home===state.userTeamId ? tie.away : tie.home;
    const isHome = tie.home===state.userTeamId;
    const faseNome = TACA_FASE_LABEL[tp.fase].replace('Taça de Portugal — ','');
    const title = `${faseNome}: ${myTeam().name} ${isHome?'recebe':'visita'} ${state.teams[oppId].name} amanhã`;
    const rows = `<div class="jr-row jr-me">
      <span class="jr-pos"></span>
      <button class="jr-team-link jr-home" data-team="${tie.home}">${state.teams[tie.home].name}</button>
      <span class="jr-score">vs</span>
      <button class="jr-team-link jr-away" data-team="${tie.away}">${state.teams[tie.away].name}</button>
      <span class="jr-pos"></span>
    </div>`;
    pushNews(state.currentDate, rows, "jogo", title);
  }
  const TACA_PASSOU_TEXTOS=[
    d=>`${d.clube} segue em frente na Taça depois de vencer ${d.adversario} por ${d.resultado}, nos ${d.fase}.`,
    d=>`Apuramento confirmado: ${d.clube} elimina ${d.adversario} (${d.resultado}) e passa os ${d.fase}.`,
    d=>`${d.clube} carimba a passagem nos ${d.fase}, após o ${d.resultado} frente a ${d.adversario}.`,
    d=>`Taça de Portugal: vitória por ${d.resultado} contra ${d.adversario} coloca ${d.clube} na eliminatória seguinte.`];
  function tacaUserTie(fase){return ((state.tacaPortugal&&state.tacaPortugal.jogos[fase])||[]).find(j=>j.home===state.userTeamId||j.away===state.userTeamId)||null;}
  function tacaPublishUserDrawNews(fase){
    const tie=tacaUserTie(fase);if(!tie||!tie.date)return;const opp=tie.home===state.userTeamId?tie.away:tie.home;
    const local=isTacaFinalFourFase(fase)?"em campo neutro":(tie.home===state.userTeamId?"em casa":"fora");const nome=TACA_FASE_LABEL[fase].replace("Taça de Portugal — ","");
    pushNews(state.currentDate,`${myTeam().name} vai jogar ${local} contra ${teamLinkHtml(opp)}, nos ${nome}, a ${fmtDateLong(new Date(tie.date))}.`,"sistema",`Sorteio da Taça: ${myTeam().name} defronta ${state.teams[opp].name}`);}
  function tacaPublishUserOutcomeNews(fase){
    const tie=tacaUserTie(fase);if(!tie||!tie.played)return;const opp=tie.home===state.userTeamId?tie.away:tie.home;
    const meu=tie.home===state.userTeamId?tie.homeScore:tie.awayScore,adv=tie.home===state.userTeamId?tie.awayScore:tie.homeScore;
    const resultado=`${meu}-${adv}${tie.soWinner?' (g.p.)':''}`,nome=TACA_FASE_LABEL[fase].replace("Taça de Portugal — ","");
    if(tacaTieWinner(tie)===state.userTeamId&&fase!=="final"){const d={clube:teamLinkHtml(state.userTeamId),adversario:teamLinkHtml(opp),resultado,fase:nome};pushNews(state.currentDate,TACA_PASSOU_TEXTOS[rnd(0,TACA_PASSOU_TEXTOS.length-1)](d),"jogo",`${myTeam().name} passa os ${nome}`,{autoAdvanceStop:true});}
    else if(tacaTieWinner(tie)!==state.userTeamId){const local=isTacaFinalFourFase(fase)?"em campo neutro":(tie.home===state.userTeamId?"em casa":"fora");pushNews(state.currentDate,`${myTeam().name} foi eliminado da Taça de Portugal nos ${nome}, após perder ${local} com ${teamLinkHtml(opp)} por ${resultado}.`,"jogo",`${myTeam().name} eliminado da Taça de Portugal`,{autoAdvanceStop:true});}}
  // Correcao (2026-09-09): a Taca de Portugal e uma competicao exclusivamente portuguesa (RGHP,
  // aberta a Placard/2a/3a Divisao) — clubes da OK Liga (Espanha) e da Serie A1 (Italia), que
  // entretanto passaram a existir em state.teams, nunca podem ser elegiveis. Sem este filtro por
  // divisaoAtual, tacaEligibleTeams() devolvia TODOS os clubes (excepto equipas B), incluindo os
  // estrangeiros, que apareciam depois escalados no sorteio da Pre-Eliminatoria.
  const TACA_DIVISOES_ELEGIVEIS = {"placard":true,"2div":true,"3div":true};
  function tacaEligibleTeams(){
    return Object.values(state.teams).filter(t=>!t.equipaPrincipalId && TACA_DIVISOES_ELEGIVEIS[t.divisaoAtual]).map(t=>t.id);
  }
  function makeCupTie(a,b){
    // "Sorteada" — a primeira equipa do par joga em casa até aos Quartos; a partir da Final
    // Four o recinto é sempre neutro (não se guarda casa/fora para essas duas rondas).
    return { home:a, away:b, homeScore:0, awayScore:0, soWinner:null, played:false, date:null, winner:null };
  }
  // Regulamento (Artigo 93.º/99.º do RGHP): os jogos da Final Four (meias-finais e final)
  // realizam-se sempre no mesmo recinto, "considerado como neutro ou neutralizado" — nenhuma
  // das duas equipas joga "em casa". `tie.home`/`tie.away` continuam a existir (ordem do sorteio,
  // cores, etc.), mas o motor de jogo não deve aplicar a vantagem de jogar em casa nestas rondas.
  function isTacaFinalFourFase(fase){
    return fase==="meiafinal" || fase==="final";
  }
  function tacaTieWinner(tie){
    if(!tie.played) return null;
    if(tie.homeScore>tie.awayScore) return tie.home;
    if(tie.awayScore>tie.homeScore) return tie.away;
    // tie.soWinner guarda "home"/"away" (indicador relativo a este jogo, tal como ctx.soWinner
    // do motor de jogo) — nunca um ID de equipa diretamente; converte-se aqui, no ponto de uso.
    if(tie.soWinner==="home") return tie.home;
    if(tie.soWinner==="away") return tie.away;
    return null;
  }

  // Sorteio da Pré-Eliminatória e dos byes — só entre clubes da 2ª/3ª Divisão (ver nota acima).
  function tacaBuildPreEliminatoriaAndByes(nonPlacardTeams){
    const shuffled = shuffleArray(nonPlacardTeams);
    const targetNonPlacardByes = 64 - 14; // 14 clubes do Placard já têm bye garantido
    if(shuffled.length <= targetNonPlacardByes){
      return { preElimJogos: [], byes: shuffled };
    }
    const excesso = shuffled.length - targetNonPlacardByes;
    const jogosPreliminares = excesso;
    const equipasPreliminar = jogosPreliminares*2;
    const preElimTeams = shuffled.slice(0, equipasPreliminar);
    const byes = shuffled.slice(equipasPreliminar);
    const jogos = [];
    for(let i=0;i<preElimTeams.length;i+=2) jogos.push(makeCupTie(preElimTeams[i], preElimTeams[i+1]));
    return { preElimJogos: jogos, byes };
  }
  // Sorteio especial dos 32 Avos: os clubes do Placard nunca se defrontam entre si.
  // Devolve { jogos, bye }: com os números fixos atuais (14 do Placard + 50 dos restantes
  // escalões = 64 sempre par) "bye" é sempre null; fica só como proteção caso o número total de
  // clubes alguma vez deixe de ser par (ex.: um clube removido de state.teams a meio da época) —
  // correção de um bug em que, nesse cenário, o último clube da lista desaparecia do quadro sem
  // jogo nem aviso.
  function tacaDraw32Avos(teams){
    const placardIds = shuffleArray(teams.filter(id=>state.teams[id].divisaoAtual==="placard"));
    const outros = shuffleArray(teams.filter(id=>state.teams[id].divisaoAtual!=="placard"));
    const jogos = [];
    let oi = 0;
    placardIds.forEach(pid=>{
      if(oi<outros.length){ jogos.push(makeCupTie(pid, outros[oi])); oi++; }
    });
    const usedPlacard = Math.min(placardIds.length, oi);
    const restantesPlacard = placardIds.slice(usedPlacard); // vazio no caso normal (mais "outros" que Placard)
    const restantesOutros = outros.slice(oi);
    const restantes = shuffleArray(restantesPlacard.concat(restantesOutros));
    let bye = null;
    for(let i=0;i<restantes.length;i+=2){
      if(restantes[i+1]!=null){ jogos.push(makeCupTie(restantes[i], restantes[i+1])); }
      else { bye = restantes[i]; console.error("Taça de Portugal: número ímpar de clubes ao sortear os 32 Avos — atribuído bye a", bye); }
    }
    return { jogos, bye };
  }
  // Sorteio livre (16 Avos em diante): sem cabeças de série, sem proteção nenhuma.
  function tacaDrawFreeRound(teams){
    const shuffled = shuffleArray(teams);
    const jogos = [];
    for(let i=0;i<shuffled.length;i+=2) jogos.push(makeCupTie(shuffled[i], shuffled[i+1]));
    return jogos;
  }

  // Datas-alvo por fase, dentro da janela sugerida (Novembro a final de Abril), com uma folga
  // de alguns dias entre a criação da ronda e o jogo em si — mesmo princípio já usado nos
  // outros calendários do jogo (base fixa por época + avanço de um ano por época).
  // Correção: a Taça estava a cair, por coincidência de calendário, nos mesmos dias da liga
  // (a liga joga sempre ao domingo) — impossível na realidade, uma equipa não pode jogar dois
  // jogos no mesmo dia. As rondas normais da Taça passam a cair sempre à quarta-feira; o Final
  // Four passa a cair sempre num fim de semana (sábado as meias-finais, domingo a final) —
  // esse fim de semana específico nunca pode ter jogos de nenhuma liga (ver
  // avoidFinalFourCollisions, chamada uma vez por época, logo a seguir a sortear o quadro).
  const TACA_WEEKDAY = 3; // quarta-feira (0=domingo)
  function nextWeekday(date, targetDow){
    const d = new Date(date);
    const diff = (targetDow - d.getDay() + 7) % 7;
    d.setDate(d.getDate() + diff);
    return d;
  }
  function tacaTargetDateForFase(fase){
    const y = 2026 + (state.season-1);
    // Correção (bug real reportado pelo utilizador, 2026-09-27: "a final four da taça de
    // portugal joga-se no final de abril") — meiafinal/final procuravam, cada uma por si, o
    // sábado/domingo "seguinte" a partir de uma data-base própria (25/26 de abril). Como
    // nextWeekday só anda para a FRENTE a partir dessa data, se 25 de abril calhasse depois do
    // sábado dessa semana (ex.: fosse ela própria um domingo), a procura saltava logo para o
    // sábado seguinte — uma semana inteira depois, já em maio (confirmado: nas épocas 1 e 6
    // desta carreira, a Final Four caía a 1-2 de maio, não no fim de semana pretendido). Passa a
    // ancorar-se sempre no ÚLTIMO sábado de abril (lastWeekdayOfMonth, mesmo padrão já usado
    // pela Elite Cup para "o último fim de semana de setembro") e a final é sempre o dia seguinte
    // — garante as duas sempre no mesmo fim de semana, sempre dentro (ou, no máximo, a 1 dia) do
    // fim de abril, nunca a saltar uma semana inteira.
    if(fase==="meiafinal") return lastWeekdayOfMonth(y+1, 3, 6); // último sábado de abril
    if(fase==="final") return addDays(lastWeekdayOfMonth(y+1, 3, 6), 1); // domingo seguinte
    const bases = {
      "pre-eliminatoria": new Date(y,10,15),  // meados de novembro
      "32avos": new Date(y,10,29),            // final de novembro
      "16avos": new Date(y+1,0,17),           // meados de janeiro
      "oitavos": new Date(y+1,1,14),          // meados de fevereiro
      "quartos": new Date(y+1,2,14),          // meados de março
    };
    const base = nextFixtureDateOutsideChristmasBreak(bases[fase]);
    return nextWeekday(base, TACA_WEEKDAY);
  }
  function tacaAssignDatesForFase(fase){
    const tp = state.tacaPortugal; if(!tp) return;
    const date = tacaTargetDateForFase(fase);
    // Correção (verificação pedida pelo utilizador: "confirma que não há jogos das várias
    // competições dos vários países agendados para o mesmo dia"): só o fim de semana do Final
    // Four tinha proteção (avoidFinalFourCollisions, e mesmo essa só contra as ligas domésticas)
    // — as restantes fases (incluindo os 32 avos, onde se confirmou uma colisão real com a WSE
    // Trophy) nunca eram verificadas contra NENHUMA outra prova. avoidLeagueCollisionsOnDate
    // (generalizada em 07e-copas-nacionais.js) verifica agora contra TODAS as provas conhecidas,
    // não só as ligas — chamada sempre ANTES de atribuir a data aos próprios jogos desta fase
    // (que continuam com date:null nesse momento, logo nunca colidem consigo mesmos).
    // Os clubes desta fase já são conhecidos neste momento — protege-se apenas a disponibilidade
    // real desses clubes (3.3 da auditoria externa), não o dia inteiro.
    avoidLeagueCollisionsOnDate(date, "Taça de Portugal", (tp.jogos[fase]||[]).flatMap(j=>[j.home,j.away]));
    (tp.jogos[fase]||[]).forEach(j=>{ j.date = new Date(date); });
  }
  // Chamado uma vez por época, logo a seguir a montar o quadro da Taça (initTacaPortugal): as
  // datas do Final Four já são conhecidas com antecedência (não dependem de resultado nenhum),
  // por isso a colisão pode ser detetada e corrigida logo no arranque da época, muito antes de
  // sequer chegar lá. Reagenda qualquer jornada de qualquer competição (liga) que caia em cima
  // do fim de semana do Final Four, avançando-a alguns dias — e avisa por notícia se a jornada
  // reagendada envolver o clube do utilizador.
  function avoidFinalFourCollisions(){
    const sabado = tacaTargetDateForFase("meiafinal");
    const domingo = tacaTargetDateForFase("final");
    // Correção (mesma família do bug "Copa del Rey a reagendar o Placard"): a Taça de Portugal é
    // 100% de clubes portugueses — nunca pode colidir com uma jornada da OK Liga ou da Serie A1.
    // Restringe-se a proteção só às competições cujos clubes são portugueses (reaproveita
    // teamCountry, já usado noutros pontos do jogo para o mesmo fim).
    Object.values(state.competitions).filter(comp => (comp.teamIds||[]).some(id => teamCountry(state.teams[id])==="pt")).forEach(comp=>{
      (comp.fixtures||[]).forEach(round=>{
        if(!round.date) return;
        if(sameDay(round.date, sabado) || sameDay(round.date, domingo)){
          const dataAntiga = new Date(round.date);
          round.date = addDays(round.date, 2); // avança para a terça-feira seguinte — evita tanto o domingo (dia da liga) como a quarta-feira (dia normal da Taça), sem precisar de reagendar a ronda seguinte
          const envolveUtilizador = round.some(fx=>fx.home===state.userTeamId || fx.away===state.userTeamId);
          if(envolveUtilizador){
            pushNews(state.currentDate, `Por causa do Final Four da Taça de Portugal, a jornada de ${competitionLinkHtml(comp.id)} agendada para ${fmtDateShort(dataAntiga)} foi reagendada para ${fmtDateShort(round.date)}.`, "sistema");
          }
        }
      });
    });
    rebuildGlobalAgenda();
  }
  // Início de época: monta o quadro completo (Pré-Eliminatória, se necessária, senão já entra
  // direto nos 32 Avos). Chamado uma vez por época, tal como as restantes competições.
  function initTacaPortugal(){
    const all = tacaEligibleTeams();
    const placardIds = all.filter(id=>state.teams[id].divisaoAtual==="placard");
    const nonPlacardIds = all.filter(id=>state.teams[id].divisaoAtual!=="placard");
    const { preElimJogos, byes } = tacaBuildPreEliminatoriaAndByes(nonPlacardIds);
    state.tacaPortugal = {
      epoca: state.season, fase: null, campeao: null, runnerUp: null,
      jogos: { "pre-eliminatoria":preElimJogos, "32avos":[], "16avos":[], "oitavos":[], "quartos":[], "meiafinal":[], "final":[] },
      byesPlacard: placardIds.slice(), byesNaoPlacard: byes.slice(), bye32avos: null,
    };
    if(preElimJogos.length){
      state.tacaPortugal.fase = "pre-eliminatoria";
      tacaAssignDatesForFase("pre-eliminatoria");
      tacaPublishUserDrawNews("pre-eliminatoria");
      // Correção (pedido do utilizador, 2026-09-17: "nos emails dos sorteios, o sorteio deve
      // aparecer no corpo do email"): passa a listar todos os confrontos sorteados.
      pushNews(state.currentDate, `🏆 <b>Sorteio da Pré-Eliminatória da Taça de Portugal realizado:</b><br><br>${preElimJogos.map(j=>`${teamLinkHtml(j.home)} vs ${teamLinkHtml(j.away)}`).join("<br>")}`, "sistema", "Taça de Portugal — Sorteio da Pré-Eliminatória", {autoAdvanceStop:true});
    } else {
      const draw32 = tacaDraw32Avos(placardIds.concat(byes));
      state.tacaPortugal.jogos["32avos"] = draw32.jogos;
      state.tacaPortugal.bye32avos = draw32.bye;
      state.tacaPortugal.fase = "32avos";
      tacaAssignDatesForFase("32avos");
      tacaPublishUserDrawNews("32avos");
      const byeCorpo32=draw32.bye?`<br><br><i>Com bye direto:</i> ${teamLinkHtml(draw32.bye)}`:"";
      pushNews(state.currentDate, `🏆 <b>Sorteio dos 32 Avos de Final da Taça de Portugal realizado:</b><br><br>${draw32.jogos.map(j=>`${teamLinkHtml(j.home)} vs ${teamLinkHtml(j.away)}`).join("<br>")}${byeCorpo32}`, "sistema", "Taça de Portugal — Sorteio dos 32 Avos", {autoAdvanceStop:true});
    }
    avoidFinalFourCollisions();
  }
  function tacaAdvanceToNextFase(){
    const tp = state.tacaPortugal; if(!tp) return;
    const idx = TACA_FASES.indexOf(tp.fase);
    const proxima = TACA_FASES[idx+1];
    if(!proxima) return; // era a final, tratado à parte em tacaFinishFaseIfReady
    const vencedoresAtuais = (tp.jogos[tp.fase]||[]).map(tacaTieWinner);
    let participantes;
    if(tp.fase==="pre-eliminatoria"){
      participantes = tp.byesPlacard.concat(tp.byesNaoPlacard).concat(vencedoresAtuais);
      const draw32 = tacaDraw32Avos(participantes);
      tp.jogos["32avos"] = draw32.jogos;
      tp.bye32avos = draw32.bye;
    } else {
      participantes = vencedoresAtuais;
      if(tp.fase==="32avos" && tp.bye32avos){ participantes = participantes.concat([tp.bye32avos]); tp.bye32avos = null; }
      // Diagnóstico defensivo: nenhuma ronda devia produzir um número ímpar de vencedores, nem
      // vencedores nulos/duplicados — se acontecer, é sinal de uma eliminatória mal resolvida
      // (ex.: empate sem soWinner definido) mais a montante, não algo para tentar "corrigir"
      // aqui silenciosamente.
      const semNulos = participantes.filter(id=>id==null);
      const duplicados = participantes.length - new Set(participantes).size;
      if(semNulos.length || duplicados>0 || participantes.length%2!==0){
        console.error("Taça de Portugal: participantes inválidos ao avançar de", tp.fase, "para", proxima, "— nulos:", semNulos.length, "duplicados:", duplicados, "total:", participantes.length, JSON.stringify(tp.jogos[tp.fase]));
      }
      tp.jogos[proxima] = proxima==="final" ? [] : tacaDrawFreeRound(participantes);
      if(proxima==="meiafinal"){
        // Final Four: sorteio livre das 4 equipas em 2 meias-finais — o vencedor de cada
        // meia-final vem a saber-se antes de a final poder ser sorteada (feito à parte).
      }
    }
    tp.fase = proxima;
    tacaAssignDatesForFase(proxima);
    tacaPublishUserDrawNews(proxima);
    // Correção (pedido do utilizador, 2026-09-17: "nos emails dos sorteios, o sorteio deve
    // aparecer no corpo do email"): passa a listar os confrontos sorteados desta fase.
    const paresProxima=(tp.jogos[proxima]||[]).map(j=>`${teamLinkHtml(j.home)} vs ${teamLinkHtml(j.away)}`).join("<br>");
    pushNews(state.currentDate, `🏆 <b>${TACA_FASE_LABEL[proxima]} — sorteio realizado:</b><br><br>${paresProxima||"Confrontos por definir."}`, "sistema", `${TACA_FASE_LABEL[proxima]} — Sorteio`, {autoAdvanceStop:true});
  }
  // Notícia combinada por fase (todos os resultados dessa fase numa só notícia, com o mesmo
  // estilo .jr-row das jornadas das divisões) — pedido explícito: uma notícia por jogo da Taça
  // era demasiado, uma por fase (equivalente a uma jornada) é o que faz sentido.
  function tacaBuildFaseResultsNews(fase){
    const jogos = state.tacaPortugal.jogos[fase]||[];
    if(!jogos.length) return;
    const rows = jogos.map(j=>{
      const marcador = `${j.homeScore} - ${j.awayScore}${j.soWinner?' <span style="font-size:9px;">(g.p.)</span>':''}`;
      return `<div class="jr-row ${j.home===state.userTeamId||j.away===state.userTeamId?'jr-me':''}">
        <span class="jr-pos"></span>
        <button class="jr-team-link jr-home" data-team="${j.home}">${state.teams[j.home].name}</button>
        <span class="jr-score">${marcador}</span>
        <button class="jr-team-link jr-away" data-team="${j.away}">${state.teams[j.away].name}</button>
        <span class="jr-pos"></span>
      </div>`;
    }).join("");
    const data = jogos[0].date ? fmtDateShort(jogos[0].date) : fmtDateShort(state.currentDate);
    const myTie = jogos.find(j=>j.home===state.userTeamId||j.away===state.userTeamId);
    let title = `${TACA_FASE_LABEL[fase]} — Resultados (${data})`;
    if(myTie){
      const oppId = myTie.home===state.userTeamId?myTie.away:myTie.home;
      const meuScore = myTie.home===state.userTeamId?myTie.homeScore:myTie.awayScore;
      const oppScore = myTie.home===state.userTeamId?myTie.awayScore:myTie.homeScore;
      title = `${TACA_FASE_LABEL[fase].replace('Taça de Portugal — ','')} (${data}): ${myTeam().name} ${meuScore}-${oppScore} ${state.teams[oppId].name}`;
    }
    pushNews(state.currentDate, rows, "jogo", title);
    tacaPublishUserOutcomeNews(fase);
  }
  function tacaFinishFaseIfReady(){
    const tp = state.tacaPortugal; if(!tp || tp.fase==="concluida") return;
    if(tp.fase==="meiafinal"){
      const jogos = tp.jogos.meiafinal;
      if(jogos.length<2 || !jogos.every(j=>j.played)) return;
      tacaBuildFaseResultsNews("meiafinal");
      const finalistas = jogos.map(tacaTieWinner);
      tp.jogos.final = [makeCupTie(finalistas[0], finalistas[1])];
      tp.fase = "final";
      tacaAssignDatesForFase("final");
      tacaPublishUserDrawNews("final");
      pushNews(state.currentDate, `Final da Taça de Portugal definida: ${teamLinkHtml(finalistas[0])} vs ${teamLinkHtml(finalistas[1])}.`, "sistema", null, {autoAdvanceStop:true});
      return;
    }
    if(tp.fase==="final"){
      const jogo = tp.jogos.final[0];
      if(!jogo || !jogo.played) return;
      const campeao = tacaTieWinner(jogo);
      // Supertaça António Livramento: precisa de saber também o finalista vencido, para o
      // substituir pelo vencedor da Taça caso este seja o mesmo clube do campeão nacional (regra
      // de "dobradinha" — ver computeSupertacaQualification em 07c-supertaca.js).
      const runnerUp = campeao===jogo.home ? jogo.away : jogo.home;
      tp.campeao = campeao; tp.runnerUp = runnerUp; tp.fase = "concluida";
      const team = state.teams[campeao];
      if(team) awardClubTitle(campeao,"taca-portugal",`Taça de Portugal ${seasonLabel(state.season)}`);
      pushNews(state.currentDate, `🏆 ${teamLinkHtml(campeao)} venceu a Taça de Portugal ${seasonLabel(state.season)}!`, "sistema", null, {autoAdvanceStop:true});
      return;
    }
    const jogos = tp.jogos[tp.fase]||[];
    if(!jogos.length || !jogos.every(j=>j.played)) return;
    tacaBuildFaseResultsNews(tp.fase);
    tacaAdvanceToNextFase();
  }

  // Processamento diário: joga automaticamente os jogos IA-IA agendados para hoje; se o clube
  // do utilizador tiver jogo hoje, abre a convocatória interativa (tal como qualquer outro jogo
  // importante do calendário do jogo).
  function tacaRecordTieResult(fase, idx, hs, as, soWinner){
    const tie = state.tacaPortugal.jogos[fase][idx];
    if(!tie || tie.played) return;
    tie.played = true; tie.homeScore = hs; tie.awayScore = as; tie.soWinner = soWinner || null;
    // Nota: sem notícia aqui — uma notícia por jogo era demasiado. A notícia combinada de toda
    // a fase é gerada em tacaBuildFaseResultsNews, chamada por tacaFinishFaseIfReady assim que a
    // fase inteira estiver concluída.
    tacaFinishFaseIfReady();
  }
  function processTacaPortugalForCurrentDate(){
    const tp = state.tacaPortugal;
    if(!tp || tp.fase==="concluida") return false;
    let processedAny = false;
    // Correção: várias eliminatórias partilham sempre a mesma data (é uma jornada da Taça, tal
    // como uma jornada normal) — mas esta função só resolvia UM jogo por chamada, e o avanço de
    // dia normal (botão Continuar) só a chama uma vez por dia. Isto fazia com que, depois de o
    // dia agendado passar, todas as eliminatórias exceto a primeira ficassem perdidas para
    // sempre (a data já não volta a coincidir). Corrigido para resolver aqui mesmo TODOS os
    // jogos IA-IA de hoje, parando só quando encontra o jogo do próprio utilizador (esse continua
    // a abrir a convocatória interativa, tal como antes).
    while(true){
      const jogos = tp.jogos[tp.fase]||[];
      // Correção (bug real, teste alargado de 5 épocas): "chegou ou já passou" em vez de sameDay
      // — se o dia exato desta eliminatória coincidir com o de outra prova do utilizador e a
      // vaga interativa do dia já estiver ocupada (ver guarda abaixo), a data exata passava e
      // sameDay nunca mais voltava a ser verdade, perdendo a eliminatória para sempre (e, pior,
      // deixando o handler de fim de jogo atribuir o resultado de OUTRA prova a esta, por a flag
      // pendingTacaPortugalFase ficar presa). Com "chegou ou já passou" a tentativa repete-se no
      // dia seguinte, já com a vaga livre.
      const idx = jogos.findIndex(j=>!j.played && j.date && j.date<=state.currentDate);
      if(idx<0) break;
      const tie = jogos[idx];
      const involvesUser = tie.home===state.userTeamId || tie.away===state.userTeamId;
      if(!involvesUser){
        // isPlayoff=true: cada eliminatória é a uma só mão e tem de ficar decidida aqui mesmo
        // (prolongamento + grandes penalidades se necessário) — ao contrário da Liguilha/Final da
        // 2ª Divisão (que são a duas mãos e só desempatam pelo agregado), a Taça não tem segunda
        // mão para decidir mais tarde.
        const res = simulateMatchToCompletion(tie.home, tie.away, true, isTacaFinalFourFase(tp.fase), "taca-portugal");
        tacaRecordTieResult(tp.fase, idx, res.home, res.away, res.soWinner);
        processedAny = true;
        if(tp.fase==="concluida") return true; // a ultima eliminatoria desta fase avancou logo ate ao fim da prova
        continue; // pode ja ter avancado de fase (jogos[] mudou) — reavalia do zero
      }
      // Correção: vaga única (matchDayReady/pendingFixture) partilhada com o Playoff, a
      // Supertaça e a Liguilha/Final da 2ª Divisão — se já estiver ocupada hoje por outra prova,
      // não se sobrepõe (isso corrompia o resultado da prova errada); esta eliminatória fica por
      // jogar até à próxima chamada com a vaga livre.
      if(state.matchDayReady) break;
      const oppId = tie.home===state.userTeamId ? tie.away : tie.home;
      state.pendingProvisional = { mine:ensureMinimumSquad(myTeam()), opp:ensureMinimumSquad(state.teams[oppId]) };
      state.pendingFixture = tie; state.pendingTacaPortugalFase = tp.fase; state.pendingTacaPortugalIndex = idx;
      state.pendingSuspensionServing = { home:getSuspendedIds(tie.home), away:getSuspendedIds(tie.away) };
      generatePreGameReport(tie, TACA_FASE_LABEL[tp.fase], null);
      state.matchDayReady = true; return true;
    }
    return processedAny;
  }
