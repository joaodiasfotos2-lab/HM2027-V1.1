// Pavilhão e dia de jogo (2026-10-12, pedido do utilizador: ideia 5 da sétima lista).
// Decisões de desenho confirmadas por ele:
//  - PREÇOS: preço por tipo de jogo (normal / jogo grande / amigável), bilhete de sócio (já incluído
//    na quota), escalão jovem e reformado, setor do visitante com preço próprio e promoções; a procura
//    reage ao preço (elasticidade) e ao humor dos adeptos;
//  - DIA DE JOGO: além da bilheteira, bar e restauração, merchandising por jogo e camarotes para
//    empresas;
//  - OBRAS: projetos com prazo e custo (ampliação, piso, iluminação, conforto, bar, camarotes), jogos
//    fora do pavilhão durante as obras maiores e qualidade do pavilhão (piso, iluminação e conforto)
//    com efeitos na assistência, nas lesões, no humor dos adeptos e nas exigências da Federação
//    para jogos europeus;
//  - IA simplificada: os clubes da IA têm as mesmas receitas de dia de jogo, qualidade e obras, com
//    preços de referência, promoções automáticas e obras ocasionais — sem emails.
//
// Ligações: matchAttendance (04-financas.js) usa pavilhaoAtendimento* e a capacidade efetiva;
// processMatchFinances usa pavilhaoBilheteira e pavilhaoReceitasExtra; injuryChance (06-motor-jogo.js)
// usa pavilhaoPisoMult; a obra de ampliação aprovada pela direção passa a ser uma obra com prazo
// (resolvePendingDirectionInvestments). O preço "normal" continua a ser financeiro.precoBilhete.
//
// Tudo o que não vem de regulamento é ESTIMATIVA do jogo: custos das obras, durações, elasticidade
// da procura, gasto por espectador no bar, merchandising por jogo, preços e ocupação dos camarotes,
// cota de adeptos visitantes, efeitos da qualidade e custo do pavilhão alternativo.

const PAV_NIVEIS = ["Básico", "Bom", "Muito bom", "Excelente"];
const PAV_OBRAS = {
  ampliacao:   { label: "Ampliação (+12% de lugares)", meses: 6, indisponivelMeses: 3 },
  piso:        { label: "Piso", meses: 2, indisponivelMeses: 2 },
  iluminacao:  { label: "Iluminação", meses: 2, indisponivelMeses: 0 },
  conforto:    { label: "Conforto (bancadas, acessos e balneários)", meses: 3, indisponivelMeses: 0 },
  bar:         { label: "Bar e restauração", meses: 2, indisponivelMeses: 0 },
  vip:         { label: "Camarotes (+10 lugares)", meses: 4, indisponivelMeses: 0 },
};
const PAV_ORDEM_OBRAS = ["ampliacao", "piso", "iluminacao", "conforto", "bar", "vip"];
const PAV_ELAST_BAIXA = 0.55;        // preço abaixo da referência: procura sobe devagar
const PAV_ELAST_ALTA = 2.2;          // preço acima da referência: procura cai depressa
const PAV_GRANDE_MULT = 1.3, PAV_AMIGAVEL_MULT = 0.6;
const PAV_JOVEM_QUOTA = 0.25;        // fração dos bilhetes pagos no escalão jovem/reformado
const PAV_BAR_GASTO = 0.9;           // € por espectador (nível "Bom")
const PAV_BAR_NIVEL_MULT = [0.75, 1.0, 1.3, 1.6];
const PAV_BAR_CUSTO = 0.42;          // custo de bens e pessoal sobre a receita do bar
const PAV_MERCH_FRAC = 0.10;         // do comercial anual, distribuído pelos jogos em casa
const PAV_MERCH_JOGOS = 13;
const PAV_VIP_PRECO_MULT = 8;        // preço de referência por lugar e jogo = bilhete × 8
const PAV_ALT_CAPACIDADE = 0.6, PAV_ALT_MAX = 1200, PAV_ALT_ATENDIMENTO = 0.85, PAV_ALT_ALUGUER = 1500, PAV_ALT_HUMOR = 0.4;
const PAV_EUROPA_QUALIDADE_MIN = 40, PAV_EUROPA_ADAPTACAO = 4000;
const PAV_PROMO_CUSTO = 250;

function pavIso(d){ return new Date(d || state.currentDate).toISOString().slice(0, 10); }
function pavRound5(n){ return Math.round(n / 5) * 5; }
function pavMeioEuro(n){ return Math.max(1, Math.round(n * 2) / 2); }
function pavHumor(team){ const a = typeof ensureAdeptos === "function" ? ensureAdeptos(team) : null; return a ? a.humor : 55; }
function pavTicketRef(team){ try { return Math.max(1, financeConfig(team).ticket || 5); } catch(e){ return 5; } }

// ---------------------------------------------------------------------------------------------
// Dados e qualidade
// ---------------------------------------------------------------------------------------------
function pavilhaoEnsure(team){
  if(!team || !team.financeiro || team.equipaPrincipalId || team.selecaoNacional) return null;
  if(team.pavilhao && team.pavilhao.v) return team.pavilhao;
  const rng = calibrationSeededRandom(`pav|${team.id}`);
  const rep = normalizeClubReputation(team.reputacao, team);
  const r = clamp((rep - 40) / 55, 0, 1);
  const nivel = () => Math.round(clamp(r * 3 + (rng() - 0.5) * 1.2, 0, 3));
  const cap = team.financeiro.capacidadePavilhao || 800;
  team.pavilhao = {
    v: 1, piso: nivel(), iluminacao: nivel(), conforto: nivel(),
    bar: Math.round(clamp(r * 2.2 + (rng() - 0.5), 0, 3)),
    vip: { lugares: rep >= 55 ? pavRound5(cap * 0.012 * clamp((rep - 55) / 35, 0, 1) * (0.8 + 0.4 * rng())) : 0, preco: null },
    precos: { grande: null, amigavel: null, visitante: null }, jovem: { desconto: 0 }, promocao: null, obra: null, historico: [], ultimoJogo: null,
  };
  return team.pavilhao;
}
function pavilhaoQualidade(team){
  const p = pavilhaoEnsure(team); if(!p) return 50;
  return Math.round((p.piso + p.iluminacao + p.conforto) / 9 * 100);
}
function pavilhaoIndisponivel(team){
  const p = pavilhaoEnsure(team);
  return !!(p && p.obra && p.obra.indisponivelAte && pavIso() < p.obra.indisponivelAte);
}
function pavilhaoCapacidade(team){
  const cap = team.financeiro.capacidadePavilhao || 0;
  return pavilhaoIndisponivel(team) ? Math.max(50, Math.round(Math.min(cap * PAV_ALT_CAPACIDADE, PAV_ALT_MAX))) : cap;
}
function pavilhaoPisoMult(team){
  const p = team && pavilhaoEnsure(team); if(!p) return 1;
  return pavilhaoIndisponivel(team) ? 1.07 : 1.07 - 0.025 * p.piso;
}

// ---------------------------------------------------------------------------------------------
// Preços e procura
// ---------------------------------------------------------------------------------------------
function pavilhaoTipoJogo(home, away, opts){
  opts = opts || {};
  if(opts.amigavel) return "amigavel";
  if(opts.playoff || opts.europa) return "grande";
  if(typeof isDerby === "function" && isDerby(home.id, away.id)) return "grande";
  const rh = normalizeClubReputation(home.reputacao, home), ra = normalizeClubReputation(away.reputacao, away);
  return (ra >= 85 || ra >= rh + 12) ? "grande" : "normal";
}
function pavilhaoPreco(team, tipo){
  const p = pavilhaoEnsure(team); const f = team.financeiro;
  const normal = f.precoBilhete || pavTicketRef(team);
  if(tipo === "grande") return p && p.precos.grande != null ? p.precos.grande : pavMeioEuro(normal * PAV_GRANDE_MULT);
  if(tipo === "amigavel") return p && p.precos.amigavel != null ? p.precos.amigavel : pavMeioEuro(normal * PAV_AMIGAVEL_MULT);
  if(tipo === "visitante") return p && p.precos.visitante != null ? p.precos.visitante : normal;
  return normal;
}
function pavilhaoPrecoReferencia(team, tipo){
  const base = pavTicketRef(team) * (tipo === "grande" ? PAV_GRANDE_MULT : tipo === "amigavel" ? PAV_AMIGAVEL_MULT : 1);
  return base * (0.8 + pavHumor(team) / 250);
}
function pavilhaoFatorPreco(team, tipo, preco){
  const ratio = pavilhaoPrecoReferencia(team, tipo) / Math.max(0.5, preco);
  return clamp(Math.pow(ratio, ratio >= 1 ? PAV_ELAST_BAIXA : PAV_ELAST_ALTA), 0.1, 1.25);
}
function pavilhaoPromocaoAtiva(team){ const p = pavilhaoEnsure(team); return p && p.promocao && p.promocao.jogos > 0 ? p.promocao : null; }
// Multiplicador total da assistência (os sócios não reagem ao preço; só a parte que paga).
function pavilhaoAtendimentoMult(home, away, opts){
  const p = pavilhaoEnsure(home); if(!p) return 1;
  const tipo = pavilhaoTipoJogo(home, away, opts);
  const percSocios = home.financeiro.percSocios != null ? home.financeiro.percSocios : 0.3;
  const promo = pavilhaoPromocaoAtiva(home);
  let pagos = pavilhaoFatorPreco(home, tipo, pavilhaoPreco(home, tipo));
  if(promo && promo.tipo === "desconto") pagos *= 1.08 * pavilhaoFatorPreco(home, tipo, pavilhaoPreco(home, tipo) * (1 - promo.desc)) / pavilhaoFatorPreco(home, tipo, pavilhaoPreco(home, tipo));
  if(promo && promo.tipo === "criancas") pagos *= 1.05;
  pagos *= 1 + p.jovem.desconto * 0.10;
  const qual = 0.96 + 0.08 * pavilhaoQualidade(home) / 100;
  const alt = pavilhaoIndisponivel(home) ? PAV_ALT_ATENDIMENTO : 1;
  return qual * alt * (percSocios + (1 - percSocios) * pagos);
}

// Quantos visitantes (adeptos do adversário) vêm e a que preço.
function pavilhaoVisitantes(home, away, assistencia){
  let distancia = 1;
  try { const v = viagemInfo(home, away, null); distancia = [1.2, 1.0, 0.15, 0.1][v.tier]; } catch(e){}
  const rep = normalizeClubReputation(away.reputacao, away);
  const preco = pavilhaoPreco(home, "visitante");
  const fatorPreco = clamp(Math.pow(pavilhaoPrecoReferencia(home, "normal") / Math.max(0.5, preco), 0.8), 0.3, 1.4);
  return Math.round(assistencia * 0.05 * (0.5 + rep / 100) * distancia * fatorPreco);
}

// Bilheteira: sócios entram pela quota; os restantes pagam consoante o tipo de jogo, escalões e promoção.
function pavilhaoBilheteira(home, away, pagos, opts){
  const p = pavilhaoEnsure(home);
  const tipo = pavilhaoTipoJogo(home, away, opts);
  const preco = pavilhaoPreco(home, tipo);
  if(!p) return { total: pagos * (home.financeiro.precoBilhete || 0), visitantes: 0, tipo, preco, promo: null };
  const visitantes = Math.min(pagos, pavilhaoVisitantes(home, away, pagos + Math.round(pagos * 0.3)));
  const promo = pavilhaoPromocaoAtiva(home);
  const geral = Math.max(0, pagos - visitantes);
  const jovens = p.jovem.desconto > 0 ? Math.round(geral * PAV_JOVEM_QUOTA) : 0;
  const gratis = promo && promo.tipo === "criancas" ? Math.round(geral * 0.15) : 0;
  const precoG = preco * (promo && promo.tipo === "desconto" ? 1 - promo.desc : 1);
  const total = (geral - jovens - gratis) * precoG + jovens * precoG * (1 - p.jovem.desconto) + visitantes * pavilhaoPreco(home, "visitante");
  return { total: Math.round(total), visitantes, tipo, preco: precoG, promo };
}

// Bar, merchandising, camarotes, aluguer do pavilhão alternativo, adaptações europeias e promoções.
function pavilhaoReceitasExtra(home, away, assistencia, opts, date, esgotado){
  const p = pavilhaoEnsure(home); if(!p) return null;
  opts = opts || {};
  const tipo = pavilhaoTipoJogo(home, away, opts);
  const alt = pavilhaoIndisponivel(home);
  const humor = pavHumor(home);
  const promo = opts.amigavel ? null : pavilhaoPromocaoAtiva(home);
  const out = { bar: 0, merch: 0, vip: 0 };
  // Bar e restauração
  const gasto = PAV_BAR_GASTO * PAV_BAR_NIVEL_MULT[p.bar] * (esgotado ? 1.08 : 1) * (promo && promo.tipo === "criancas" ? 1.06 : 1) * (alt ? 0.5 : 1) * (0.9 + humor / 500);
  out.bar = Math.round(assistencia * gasto);
  if(out.bar > 0){
    addFinanceMovement(home, "receita", "Bar e restauração", `Bar e restauração — ${assistencia} espectadores (${PAV_NIVEIS[p.bar].toLowerCase()})`, out.bar, date);
    addFinanceMovement(home, "despesa", "Organização", "Custos do bar e restauração (bens e pessoal)", Math.round(out.bar * PAV_BAR_CUSTO), date);
  }
  if(!opts.amigavel){
    // Merchandising por jogo
    const base = Math.max(0, home.financeiro.receitaMensalComercial || 0) * 12 * PAV_MERCH_FRAC / PAV_MERCH_JOGOS;
    out.merch = Math.round(base * (tipo === "grande" ? 1.25 : 1) * (esgotado ? 1.15 : 1) * (0.8 + humor / 250) * (alt ? 0.6 : 1) * (0.8 + Math.random() * 0.4));
    if(out.merch > 0) addFinanceMovement(home, "receita", "Merchandising", "Merchandising vendido no pavilhão", out.merch, date);
    // Camarotes e empresas
    if(p.vip.lugares > 0 && !alt){
      const ref = pavTicketRef(home) * PAV_VIP_PRECO_MULT;
      const preco = p.vip.preco != null ? p.vip.preco : Math.round(ref);
      const ocup = clamp((0.45 + (humor - 50) * 0.005 + (esgotado ? 0.15 : 0) + (tipo === "grande" ? 0.1 : 0)) * Math.pow(ref * (0.8 + humor / 250) / Math.max(1, preco), 0.8), 0.05, 0.98);
      out.vip = Math.round(p.vip.lugares * ocup * preco * (0.9 + Math.random() * 0.2));
      if(out.vip > 0) addFinanceMovement(home, "receita", "Camarotes e empresas", `Camarotes: ${p.vip.lugares} lugares, ocupação ${Math.round(ocup * 100)}%`, out.vip, date);
    }
  }
  if(alt) addFinanceMovement(home, "despesa", "Organização", "Aluguer de pavilhão alternativo (obras no pavilhão)", Math.round(PAV_ALT_ALUGUER * clubFinancialStructureFactor(home)), date);
  if(opts.europa && pavilhaoQualidade(home) < PAV_EUROPA_QUALIDADE_MIN){
    addFinanceMovement(home, "despesa", "Organização", "Adaptações exigidas pela organização europeia (qualidade do pavilhão)", PAV_EUROPA_ADAPTACAO, date);
    out.adaptacao = PAV_EUROPA_ADAPTACAO;
  }
  if(promo && !opts.amigavel){
    addFinanceMovement(home, "despesa", "Organização", "Campanha promocional do jogo", PAV_PROMO_CUSTO, date);
    promo.jogos -= 1;
    if(promo.jogos <= 0) p.promocao = null;
  }
  return out;
}
// Jogo de preparação em casa (08e-preepoca.js): bilheteira ao preço de amigável (metade do público) e bar.
function pavilhaoAmigavel(home, away, date){
  const p = pavilhaoEnsure(home); if(!p) return null;
  const opts = { amigavel: true };
  const assistencia = Math.round(matchAttendance(home, away, opts) * 0.5);
  const percSocios = home.financeiro.percSocios != null ? home.financeiro.percSocios : 0.3;
  const pagos = assistencia - Math.round(assistencia * percSocios);
  const bil = pavilhaoBilheteira(home, away, pagos, opts);
  if(bil.total > 0) addFinanceMovement(home, "receita", "Bilheteira", `Jogo de preparação com o ${away.name} · ${pagos} bilhetes pagos`, bil.total, date);
  pavilhaoReceitasExtra(home, away, assistencia, opts, date, false);
  return { assistencia, bilheteira: bil.total };
}
// Chamado no fim de processMatchFinances: resumo do jogo e promoção automática da IA.
function pavilhaoAposJogo(home, away, assistencia, info){
  const p = pavilhaoEnsure(home); if(!p) return;
  p.ultimoJogo = Object.assign({ data: pavIso(), adversario: away.name, assistencia }, info || {});
  if(!isUserControlledTeam(home) && !p.promocao){
    const cap = pavilhaoCapacidade(home);
    if(cap > 0 && assistencia / cap < 0.45) p.promocao = { tipo: "desconto", desc: 0.3, jogos: 2 };
  }
}

// ---------------------------------------------------------------------------------------------
// Obras
// ---------------------------------------------------------------------------------------------
function pavilhaoNivelObra(team, tipo){ const p = pavilhaoEnsure(team); return tipo === "ampliacao" ? 0 : tipo === "vip" ? p.vip.lugares / 10 : p[tipo]; }
function pavilhaoObraMaxima(team, tipo){
  const p = pavilhaoEnsure(team);
  if(tipo === "ampliacao") return false;
  if(tipo === "vip") return p.vip.lugares >= 60;
  return p[tipo] >= 3;
}
function pavilhaoCustoObra(team, tipo){
  const cap = team.financeiro.capacidadePavilhao || 800;
  const sf = clubFinancialStructureFactor(team);
  const p = pavilhaoEnsure(team);
  if(tipo === "ampliacao") return pavilionUpgradeCost(team);
  if(tipo === "piso") return Math.max(3000, Math.round(cap * 60 * sf * (1 + 0.5 * p.piso)));
  if(tipo === "iluminacao") return Math.max(2500, Math.round(cap * 45 * sf * (1 + 0.5 * p.iluminacao)));
  if(tipo === "conforto") return Math.max(4000, Math.round(cap * 70 * sf * (1 + 0.6 * p.conforto)));
  if(tipo === "bar") return Math.max(2000, Math.round(cap * 25 * sf * (1 + 0.7 * p.bar)));
  if(tipo === "vip") return Math.max(5000, Math.round(10 * 1500 * sf));
  return 0;
}
function pavilhaoPodeIniciarObra(team, tipo, opts){
  const p = pavilhaoEnsure(team); const f = team.financeiro;
  if(!p || !PAV_OBRAS[tipo]) return { ok: false, reason: "Obra desconhecida." };
  if(p.obra) return { ok: false, reason: "Já há uma obra em curso no pavilhão." };
  if(pavilhaoObraMaxima(team, tipo)) return { ok: false, reason: "Este item já está no nível máximo." };
  if(opts && opts.custoPago) return { ok: true };
  const custo = pavilhaoCustoObra(team, tipo);
  if((f.divida || 0) > 0) return { ok: false, reason: "O clube tem dívida por regularizar: a direção não autoriza obras." };
  if((f.saldo || 0) - custo < financeSurvivalReserve(team, DIRECAO_INVESTIMENTO_CONFIG.reservaMesesSobrevivencia)) return { ok: false, reason: "A obra poria em causa a reserva mínima de sobrevivência do clube." };
  return { ok: true, custo };
}
function pavilhaoIniciarObra(team, tipo, opts){
  opts = opts || {};
  const ok = pavilhaoPodeIniciarObra(team, tipo, opts);
  if(!ok.ok) return ok;
  const p = pavilhaoEnsure(team); const cfg = PAV_OBRAS[tipo];
  const custo = opts.custoPago ? (opts.custo || 0) : pavilhaoCustoObra(team, tipo);
  const hoje = new Date(state.currentDate);
  const fim = new Date(hoje.getTime() + cfg.meses * 30 * 86400000);
  const indisp = cfg.indisponivelMeses ? new Date(hoje.getTime() + cfg.indisponivelMeses * 30 * 86400000) : null;
  p.obra = { tipo, inicio: pavIso(hoje), fim: pavIso(fim), indisponivelAte: indisp ? pavIso(indisp) : null, custo, alvoCapacidade: opts.alvoCapacidade || null };
  if(!opts.custoPago) addFinanceMovement(team, "despesa", "Investimento", `Obras no pavilhão (${cfg.label}) — 1.ª metade`, Math.round(custo / 2), state.currentDate);
  p.obra.segundaMetadePaga = !!opts.custoPago;
  if(isUserControlledTeam(team)){
    pushNews(state.currentDate, `Arrancaram as obras no pavilhão: <b>${escapeHtml(cfg.label)}</b>. Prazo: ${fmtDateShort(fim)}.${indisp ? ` Até ${fmtDateShort(indisp)} o pavilhão fica indisponível: os jogos em casa são disputados noutro pavilhão (capacidade reduzida, menos assistência e mais custos).` : ""} Custo total: ${fmtMoney(custo)}.`, "direcao", `Obras no pavilhão: ${cfg.label}`, { teamId: team.id });
  }
  return { ok: true, custo, fim: p.obra.fim };
}
function pavilhaoConcluirObra(team){
  const p = pavilhaoEnsure(team); if(!p || !p.obra) return;
  const o = p.obra, cfg = PAV_OBRAS[o.tipo];
  if(!o.segundaMetadePaga) addFinanceMovement(team, "despesa", "Investimento", `Obras no pavilhão (${cfg.label}) — 2.ª metade`, Math.round(o.custo - Math.round(o.custo / 2)), state.currentDate);
  if(o.tipo === "ampliacao") team.financeiro.capacidadePavilhao = o.alvoCapacidade || (team.financeiro.capacidadePavilhao + pavilionUpgradeStep(team));
  else if(o.tipo === "vip") p.vip.lugares += 10;
  else p[o.tipo] = Math.min(3, p[o.tipo] + 1);
  p.historico.unshift({ tipo: o.tipo, concluida: pavIso(), custo: o.custo }); if(p.historico.length > 12) p.historico.length = 12;
  p.obra = null;
  if(isUserControlledTeam(team)){
    pushNews(state.currentDate, `Obras concluídas no pavilhão: <b>${escapeHtml(cfg.label)}</b>. ${o.tipo === "ampliacao" ? `A capacidade passa a ${team.financeiro.capacidadePavilhao} lugares.` : "As melhorias já estão em funcionamento."}`, "direcao", `Obras concluídas: ${cfg.label}`, { teamId: team.id, autoAdvanceStop: true });
  }
}
function pavilhaoDiario(){
  Object.values(state.teams).forEach(team => {
    const p = team.pavilhao;
    if(p && p.obra && pavIso() >= p.obra.fim) pavilhaoConcluirObra(team);
  });
}

// Mensal: efeitos da qualidade e do pavilhão alternativo no humor dos adeptos; obras ocasionais da IA.
function pavilhaoMensal(date){
  Object.values(state.teams).forEach(team => {
    const p = pavilhaoEnsure(team); if(!p) return;
    const d = new Date(date), mesKey = `${d.getFullYear()}-${d.getMonth() + 1}`;
    if(p.ultimoMes === mesKey) return;
    p.ultimoMes = mesKey;
    const a = typeof ensureAdeptos === "function" ? ensureAdeptos(team) : null;
    if(a){
      const q = pavilhaoQualidade(team);
      // Preços muito acima da referência irritam os adeptos; muito abaixo agradam (estimativa).
      const rel = pavilhaoPreco(team, "normal") / Math.max(0.5, pavilhaoPrecoReferencia(team, "normal"));
      const precoHumor = rel > 1.6 ? -0.3 : rel > 1.3 ? -0.12 : rel < 0.7 ? 0.2 : 0;
      a.humor = clamp(a.humor + (q >= 75 ? 0.15 : q < 25 ? -0.15 : 0) + precoHumor - (pavilhaoIndisponivel(team) ? PAV_ALT_HUMOR : 0), 0, 100);
    }
    if(isUserControlledTeam(team) || p.obra || Math.random() > 0.015) return;
    // IA: melhora primeiro o que está pior; só amplia se enche o pavilhão
    const f = team.financeiro;
    const cand = ["piso", "iluminacao", "conforto"].filter(t => p[t] < 3).sort((x, y) => p[x] - p[y]);
    let tipo = cand.length && Math.random() < 0.6 ? cand[0] : null;
    if(!tipo){
      const cap = f.capacidadePavilhao || 1;
      const escolhas = [];
      if(p.bar < 3) escolhas.push("bar");
      if(p.vip.lugares < 60 && normalizeClubReputation(team.reputacao, team) >= 55) escolhas.push("vip");
      if((f.mediaAssistencia || 0) / cap >= 0.85) escolhas.push("ampliacao");
      tipo = escolhas.length ? escolhas[Math.floor(Math.random() * escolhas.length)] : (cand[0] || null);
    }
    if(!tipo) return;
    const custo = pavilhaoCustoObra(team, tipo);
    if((f.saldo || 0) < custo * 3 || (f.divida || 0) > 0) return;
    pavilhaoIniciarObra(team, tipo, tipo === "ampliacao" ? { alvoCapacidade: (f.capacidadePavilhao || 0) + pavilionUpgradeStep(team) } : {});
  });
}

// ---------------------------------------------------------------------------------------------
// Interface
// ---------------------------------------------------------------------------------------------
function pavilhaoPanelHtml(team){
  const p = pavilhaoEnsure(team); if(!p) return "";
  const f = team.financeiro;
  const q = pavilhaoQualidade(team);
  const ref = pavTicketRef(team);
  const ob = p.obra;
  const obraHtml = ob
    ? `<p class="helptext">Obra em curso: <b>${escapeHtml(PAV_OBRAS[ob.tipo].label)}</b>, termina a ${fmtDateShort(new Date(ob.fim))}.${ob.indisponivelAte && pavIso() < ob.indisponivelAte ? ` Pavilhão indisponível até ${fmtDateShort(new Date(ob.indisponivelAte))} (jogos noutro pavilhão).` : ""}</p>`
    : `<p class="helptext" style="margin:4px 0;">As obras só arrancam depois de a direção as avaliar e aprovar (resposta em 2 a 4 semanas; um pedido de cada vez).</p><div style="display:flex;gap:6px;flex-wrap:wrap;margin:6px 0;">${PAV_ORDEM_OBRAS.filter(t => !pavilhaoObraMaxima(team, t)).map(t => `<button class="btn btn-ghost pav-obra" data-tipo="${t}">${escapeHtml(PAV_OBRAS[t].label)} · ${fmtMoney(t === "ampliacao" ? pavilionUpgradeCost(team) : pavilhaoCustoObra(team, t))} · ${PAV_OBRAS[t].meses} meses${PAV_OBRAS[t].indisponivelMeses ? " (pavilhão fechado " + PAV_OBRAS[t].indisponivelMeses + ")" : ""}</button>`).join("")}</div>`;
  const promo = pavilhaoPromocaoAtiva(team);
  const uj = p.ultimoJogo;
  const num = (id, v, step) => `<input type="number" id="${id}" value="${v}" min="1" max="${id === "pavPrecoVip" ? 500 : 30}" step="${step || 0.5}" style="width:78px;">`;
  return `<div class="eyebrow" style="margin:16px 0 8px;">Pavilhão e dia de jogo</div>
    <p class="helptext" style="margin-bottom:8px;">Capacidade ${pavilhaoCapacidade(team)} lugares${pavilhaoIndisponivel(team) ? " (pavilhão alternativo)" : ""} · Piso ${PAV_NIVEIS[p.piso]} · Iluminação ${PAV_NIVEIS[p.iluminacao]} · Conforto ${PAV_NIVEIS[p.conforto]} (qualidade ${q}/100) · Bar ${PAV_NIVEIS[p.bar]} · Camarotes: ${p.vip.lugares} lugares. A qualidade influencia a assistência, as lesões, o humor dos adeptos e as exigências para jogos europeus (mínimo ${PAV_EUROPA_QUALIDADE_MIN}). Custos e efeitos são estimativas do jogo.</p>
    ${obraHtml}
    <div class="eyebrow" style="margin:10px 0 6px;">Preços (referência do mercado: ${fmtMoney(ref)})</div>
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
      <label style="font-size:12px;">Normal ${num("pavPrecoNormal", f.precoBilhete)}</label>
      <label style="font-size:12px;">Jogo grande ${num("pavPrecoGrande", pavilhaoPreco(team, "grande"))}</label>
      <label style="font-size:12px;">Amigável ${num("pavPrecoAmigavel", pavilhaoPreco(team, "amigavel"))}</label>
      <label style="font-size:12px;">Visitante ${num("pavPrecoVisitante", pavilhaoPreco(team, "visitante"))}</label>
      <label style="font-size:12px;">Camarote/lugar ${num("pavPrecoVip", p.vip.preco != null ? p.vip.preco : Math.round(ref * PAV_VIP_PRECO_MULT), 5)}</label>
      <label style="font-size:12px;">Jovens e reformados <select id="pavJovem">${[0, 0.25, 0.5].map(d => `<option value="${d}" ${p.jovem.desconto === d ? "selected" : ""}>${d ? "−" + Math.round(d * 100) + "%" : "sem desconto"}</option>`).join("")}</select></label>
      <button class="btn btn-primary" id="pavGuardarPrecos">Guardar preços</button>
    </div>
    <p class="helptext" style="margin-top:6px;">Os sócios entram pela quota. Subir o preço acima da referência faz a procura cair depressa; descer só a aumenta devagar. Jogos grandes (clássicos, playoff, Europa, adversário forte) e o setor visitante têm preço próprio.</p>
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin:6px 0;">
      ${promo ? `<span class="helptext">Promoção ativa: ${promo.tipo === "desconto" ? "desconto de " + Math.round(promo.desc * 100) + "%" : "entrada livre para crianças"} (${promo.jogos} jogo${promo.jogos > 1 ? "s" : ""}).</span>`
        : `<button class="btn btn-ghost pav-promo" data-tipo="desconto">Promoção: bilhetes −30% (2 jogos, ${fmtMoney(PAV_PROMO_CUSTO)}/jogo)</button><button class="btn btn-ghost pav-promo" data-tipo="criancas">Promoção: crianças grátis (3 jogos, ${fmtMoney(PAV_PROMO_CUSTO)}/jogo)</button>`}
    </div>
    ${uj ? `<p class="helptext">Último jogo em casa (${escapeHtml(uj.adversario)}): ${uj.assistencia} espectadores · bilheteira ${fmtMoney(uj.bilheteira || 0)}${uj.visitantes != null ? ` (${uj.visitantes} visitantes)` : ""} · bar ${fmtMoney(uj.bar || 0)} · merchandising ${fmtMoney(uj.merch || 0)} · camarotes ${fmtMoney(uj.vip || 0)}.</p>` : ""}`;
}
document.addEventListener("click", (e) => {
  const t = e.target; if(!t || !t.closest) return;
  const team = myTeam(); if(!team) return;
  const redraw = () => { if(typeof renderDirectionPanel === "function") renderDirectionPanel(); };
  const ob = t.closest(".pav-obra");
  if(ob){
    const tipo = ob.getAttribute("data-tipo");
    // Obras: a direção avalia e aprova sempre (2026-10-12). A ampliação segue o pedido de capacidade já existente; as restantes
    // (piso, iluminação, conforto, bar, camarotes) são pedidos de "obras no pavilhão". Nada arranca por decisão direta do treinador.
    const r = tipo === "ampliacao" ? requestDirectionInvestment(team, "pavilhao", state.currentDate) : requestDirectionInvestment(team, "obra", state.currentDate, { obraTipo: tipo });
    showTransientNotice(r.outcome === "recusa" ? r.reason : `Pedido enviado à direção: resposta prevista a ${fmtDateShort(new Date(r.pedido.dataResposta))}.`); redraw(); return;
  }
  const pr = t.closest(".pav-promo");
  if(pr){
    const p = pavilhaoEnsure(team);
    if(p.promocao){ showTransientNotice("Já há uma promoção ativa."); return; }
    const tipo = pr.getAttribute("data-tipo");
    p.promocao = tipo === "desconto" ? { tipo, desc: 0.3, jogos: 2 } : { tipo, desc: 0, jogos: 3 };
    showTransientNotice("Promoção ativada."); redraw(); return;
  }
  if(t.closest("#pavGuardarPrecos")){
    const v = id => parseFloat(document.getElementById(id).value);
    const p = pavilhaoEnsure(team);
    const lim = (x, a, b) => clamp(Number.isFinite(x) ? x : a, a, b);
    team.financeiro.precoBilhete = lim(v("pavPrecoNormal"), 1, 15);
    p.precos.grande = lim(v("pavPrecoGrande"), 1, 30);
    p.precos.amigavel = lim(v("pavPrecoAmigavel"), 1, 30);
    p.precos.visitante = lim(v("pavPrecoVisitante"), 1, 30);
    p.vip.preco = Math.round(lim(v("pavPrecoVip"), 5, 500));
    p.jovem.desconto = parseFloat(document.getElementById("pavJovem").value) || 0;
    showTransientNotice("Preços guardados."); redraw();
  }
});
